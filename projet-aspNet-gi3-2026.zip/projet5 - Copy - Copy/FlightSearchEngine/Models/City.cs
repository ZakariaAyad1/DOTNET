namespace FlightSearchEngine.Models
{
    public class City
    {
        public string Name { get; set; } = string.Empty;
        public string IataCode { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
    }
}
