using FlightSearchEngine.Models;
using FlightSearchEngine.Services;
using Microsoft.AspNetCore.Mvc;

namespace FlightSearchEngine.Controllers
{
    public class FlightController : Controller
    {
        private readonly IFlightSearchService _flightService;

        public FlightController(IFlightSearchService flightService)
        {
            _flightService = flightService;
        }

        public IActionResult Index()
        {
            var model = new FlightSearchRequest
            {
                DepartureDate = DateTime.Today.AddDays(7),
                ReturnDate = DateTime.Today.AddDays(14),
                IsRoundTrip = true
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Search(FlightSearchRequest request)
        {
            if (!ModelState.IsValid)
            {
                return View("Index", request);
            }

            var flights = await _flightService.SearchFlightsAsync(request);

            // Apply filters
            if (request.DirectFlightOnly)
            {
                flights = flights.Where(f => f.Itineraries.All(i => i.IsDirect())).ToList();
            }

            // Apply time filters
            if (request.DepartureTimeFrom.HasValue || request.DepartureTimeTo.HasValue)
            {
                flights = flights.Where(f =>
                {
                    var departureTime = f.Itineraries.FirstOrDefault()?.Segments.FirstOrDefault()?.Departure.At.TimeOfDay;
                    if (!departureTime.HasValue) return false;

                    if (request.DepartureTimeFrom.HasValue && departureTime < request.DepartureTimeFrom)
                        return false;
                    if (request.DepartureTimeTo.HasValue && departureTime > request.DepartureTimeTo)
                        return false;

                    return true;
                }).ToList();
            }

            if (request.ArrivalTimeFrom.HasValue || request.ArrivalTimeTo.HasValue)
            {
                flights = flights.Where(f =>
                {
                    var arrivalTime = f.Itineraries.FirstOrDefault()?.Segments.LastOrDefault()?.Arrival.At.TimeOfDay;
                    if (!arrivalTime.HasValue) return false;

                    if (request.ArrivalTimeFrom.HasValue && arrivalTime < request.ArrivalTimeFrom)
                        return false;
                    if (request.ArrivalTimeTo.HasValue && arrivalTime > request.ArrivalTimeTo)
                        return false;

                    return true;
                }).ToList();
            }

            // Apply sorting
            flights = request.SortBy switch
            {
                "price_asc" => flights.OrderBy(f => f.Price).ToList(),
                "price_desc" => flights.OrderByDescending(f => f.Price).ToList(),
                "duration_asc" => flights.OrderBy(f => f.Itineraries.FirstOrDefault()?.GetTotalMinutes() ?? 0).ToList(),
                "duration_desc" => flights.OrderByDescending(f => f.Itineraries.FirstOrDefault()?.GetTotalMinutes() ?? 0).ToList(),
                _ => flights.OrderBy(f => f.Price).ToList()
            };

            ViewBag.SearchRequest = request;
            return View("Results", flights);
        }

        [HttpGet]
        public async Task<IActionResult> SearchCities(string term)
        {
            var cities = await _flightService.SearchCitiesAsync(term);
            var result = cities.Select(c => new
            {
                label = $"{c.Name} ({c.IataCode}) - {c.Country}",
                value = c.Name,
                iataCode = c.IataCode
            });
            return Json(result);
        }

        [HttpPost]
        public IActionResult Modify(FlightSearchRequest request)
        {
            return View("Index", request);
        }
    }
}
