# 📑 Index - TP8 Services Web en C#

> **Navigation rapide vers tous les fichiers et ressources du projet**

---

## 🚀 Pour Démarrer

### Vous êtes pressé?
1. [DEMARRAGE_RAPIDE.md](DEMARRAGE_RAPIDE.md) - Démarrage en 5 minutes
2. Exécuter: `.\Deploy.ps1 -All` (PowerShell Admin)
3. Tester: `.\TestRESTService.ps1`

### Vous voulez comprendre?
1. [README.md](README.md) - Documentation complète du projet
2. [NOTES_THEORIQUES.md](NOTES_THEORIQUES.md) - Concepts et théorie
3. [STRUCTURE_PROJET.md](STRUCTURE_PROJET.md) - Architecture détaillée

---

## 📚 Documentation

| Fichier | Description | Quand l'utiliser? |
|---------|-------------|-------------------|
| [README.md](README.md) | Documentation principale complète | Pour tout comprendre en détail |
| [DEMARRAGE_RAPIDE.md](DEMARRAGE_RAPIDE.md) | Guide de démarrage express | Pour déployer rapidement |
| [NOTES_THEORIQUES.md](NOTES_THEORIQUES.md) | Concepts SOAP, REST, architecture | Pour apprendre la théorie |
| [EXEMPLES_REQUETES.md](EXEMPLES_REQUETES.md) | Exemples de tests et requêtes | Pour tester manuellement |
| [STRUCTURE_PROJET.md](STRUCTURE_PROJET.md) | Architecture et organisation | Pour comprendre l'organisation |
| [INDEX.md](INDEX.md) | Ce fichier - Navigation | Point d'entrée général |

---

## 🛠️ Scripts Utiles

### Deploy.ps1
**Usage:** Déploiement automatique sur IIS

```powershell
# Déployer tous les services
.\Deploy.ps1 -All

# Déployer uniquement SOAP
.\Deploy.ps1 -SOAP

# Déployer uniquement REST
.\Deploy.ps1 -REST
```

**Prérequis:** PowerShell en mode Administrateur

---

### TestRESTService.ps1
**Usage:** Tester automatiquement le service REST

```powershell
# Test avec URL par défaut
.\TestRESTService.ps1

# Test avec URL personnalisée
.\TestRESTService.ps1 -BaseUrl "http://localhost:8080/Client.svc"
```

**Tests effectués:**
- GET liste des clients
- GET client spécifique (IDs 1 et 2)
- POST nouveau client
- PUT modification client
- DELETE suppression client
- GET vérification finale

---

## 📂 Projets

### 1. MyFirstWebService (Service SOAP)

**Type:** Service Web ASP.NET (asmx)  
**Technologie:** .NET Framework 4.7.2  
**Port d'entrée:** `Service.asmx`

#### Fichiers principaux:
- [Service.asmx](MyFirstWebService/Service.asmx) - Point d'entrée HTTP
- [App_Code/Service.cs](MyFirstWebService/App_Code/Service.cs) - Implémentation (Add, Sub)
- [Web.config](MyFirstWebService/Web.config) - Configuration

#### Méthodes disponibles:
- `Add(int a, int b)` - Addition de deux entiers
- `Sub(int a, int b)` - Soustraction de deux entiers

#### URLs:
- Service: `http://localhost/MyFirstWebService/Service.asmx`
- WSDL: `http://localhost/MyFirstWebService/Service.asmx?wsdl`

---

### 2. MyFirstWebServiceClient (Client SOAP)

**Type:** Application Console  
**Technologie:** .NET 6.0  
**Dépendances:** System.ServiceModel.*

#### Fichiers principaux:
- [Program.cs](MyFirstWebServiceClient/Program.cs) - Application console
- [MyFirstWebServiceClient.csproj](MyFirstWebServiceClient/MyFirstWebServiceClient.csproj) - Configuration projet
- [README.md](MyFirstWebServiceClient/README.md) - Instructions référence

#### Fonctionnalités:
- Demande deux nombres à l'utilisateur
- Appelle les méthodes Add et Sub du service
- Affiche les résultats

#### Exécution:
```powershell
cd MyFirstWebServiceClient
dotnet restore
dotnet build
dotnet run
```

**Note:** Nécessite d'ajouter la référence de service (voir README du client)

---

### 3. MyFirstRESTWebService (Service REST)

**Type:** Service WCF REST  
**Technologie:** .NET Framework 4.7.2  
**Port d'entrée:** `Client.svc`

#### Fichiers principaux:
- [Client.svc](MyFirstRESTWebService/Client.svc) - Point d'entrée HTTP
- [IClient.cs](MyFirstRESTWebService/IClient.cs) - Contrat de service (interface)
- [Client.svc.cs](MyFirstRESTWebService/Client.svc.cs) - Implémentation
- [Web.config](MyFirstRESTWebService/Web.config) - Configuration minimale

#### API Endpoints:

| Méthode | URL | Action | Format |
|---------|-----|--------|--------|
| GET | `/clients` | Liste tous les clients | XML |
| GET | `/clients/{id}` | Récupère un client | XML |
| POST | `/clients` | Crée un client | JSON → JSON |
| PUT | `/clients/{id}` | Modifie un client | JSON → JSON |
| DELETE | `/clients/{id}` | Supprime un client | JSON |

#### URLs:
- Service: `http://localhost/MyFirstRESTWebService/Client.svc`
- Liste: `http://localhost/MyFirstRESTWebService/Client.svc/clients`
- Détail: `http://localhost/MyFirstRESTWebService/Client.svc/clients/1`

#### Modèle de données:
```csharp
InfoClients {
    int IdClient
    string Nom
    string Adresse
}
```

#### Données pré-chargées:
1. Dupont - 123 Rue de Paris
2. Martin - 456 Avenue des Champs
3. Bernard - 789 Boulevard Saint-Michel
4. Dubois - 321 Rue de la République
5. Thomas - 654 Avenue Victor Hugo

---

### 4. MyFirstRESTWebServiceClient (Client REST)

**Type:** Application Console Interactive  
**Technologie:** .NET 6.0  
**Dépendances:** Newtonsoft.Json

#### Fichiers principaux:
- [Program.cs](MyFirstRESTWebServiceClient/Program.cs) - Application console avec menu
- [MyFirstRESTWebServiceClient.csproj](MyFirstRESTWebServiceClient/MyFirstRESTWebServiceClient.csproj) - Configuration projet

#### Fonctionnalités (Menu interactif):
1. **GET Liste** - Afficher tous les clients
2. **GET Détail** - Afficher un client spécifique
3. **POST** - Ajouter un nouveau client
4. **PUT** - Modifier un client existant
5. **DELETE** - Supprimer un client

#### Exécution:
```powershell
cd MyFirstRESTWebServiceClient
dotnet restore
dotnet build
dotnet run
```

#### Technologies utilisées:
- `WebClient` - Requêtes HTTP
- `XDocument` - Parsing XML (GET)
- `JsonConvert` - Sérialisation JSON (POST/PUT)

---

## 🔧 Tests Manuels Rapides

### SOAP (via navigateur)
```
http://localhost/MyFirstWebService/Service.asmx
→ Cliquer sur Add ou Sub
→ Entrer les paramètres
→ Cliquer "Invoke"
```

### REST (via navigateur)
```
http://localhost/MyFirstRESTWebService/Client.svc/clients
→ Affiche la liste des clients
```

### REST (via PowerShell)
```powershell
# GET - Liste
Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients"

# GET - Détail
Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1"

# POST - Créer
$body = @{Nom="Test"; Adresse="123 Rue"} | ConvertTo-Json
Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" `
  -Method POST -ContentType "application/json" -Body $body
```

---

## 🎯 Parcours d'Apprentissage Recommandé

### 🔰 Niveau Débutant

1. **Commencez par la théorie**
   - Lisez [NOTES_THEORIQUES.md](NOTES_THEORIQUES.md) sections 1 et 2
   - Comprenez ce qu'est un service web

2. **Testez SOAP**
   - Déployez avec `.\Deploy.ps1 -SOAP`
   - Testez dans le navigateur
   - Lisez [MyFirstWebService/App_Code/Service.cs](MyFirstWebService/App_Code/Service.cs)

3. **Testez REST**
   - Déployez avec `.\Deploy.ps1 -REST`
   - Testez les URLs GET dans le navigateur
   - Exécutez `.\TestRESTService.ps1`

---

### 🔷 Niveau Intermédiaire

1. **Créez le client SOAP**
   - Suivez [MyFirstWebServiceClient/README.md](MyFirstWebServiceClient/README.md)
   - Ajoutez la référence de service
   - Exécutez et testez

2. **Utilisez le client REST**
   - Exécutez `MyFirstRESTWebServiceClient`
   - Testez toutes les opérations CRUD
   - Observez les réponses

3. **Tests manuels**
   - Utilisez [EXEMPLES_REQUETES.md](EXEMPLES_REQUETES.md)
   - Testez avec PowerShell
   - Testez avec cURL ou Postman

---

### 🔶 Niveau Avancé

1. **Analysez l'architecture**
   - Étudiez [STRUCTURE_PROJET.md](STRUCTURE_PROJET.md)
   - Comprenez les flux de communication
   - Identifiez les patterns utilisés

2. **Approfondissez la théorie**
   - Lisez [NOTES_THEORIQUES.md](NOTES_THEORIQUES.md) en entier
   - Comparez SOAP vs REST
   - Étudiez les attributs C#

3. **Expérimentez**
   - Ajoutez de nouvelles méthodes au service SOAP
   - Ajoutez des filtres au service REST (ex: `/clients?nom=Dupont`)
   - Implémentez la pagination
   - Ajoutez de la validation
   - Gérez les erreurs avec des codes HTTP appropriés

---

## 🆘 Aide et Dépannage

### Problème: Service inaccessible
**Solution:** Consultez [README.md](README.md) section "Dépannage"

### Problème: Erreur de déploiement
**Solution:** 
1. Vérifiez que PowerShell est en mode Admin
2. Consultez [DEMARRAGE_RAPIDE.md](DEMARRAGE_RAPIDE.md) section "Résolution de Problèmes"

### Problème: Client SOAP ne compile pas
**Solution:** 
1. Vérifiez que la référence de service est ajoutée
2. Consultez [MyFirstWebServiceClient/README.md](MyFirstWebServiceClient/README.md)

### Problème: Requêtes REST échouent
**Solution:**
1. Exécutez `.\TestRESTService.ps1` pour diagnostiquer
2. Consultez [EXEMPLES_REQUETES.md](EXEMPLES_REQUETES.md) section "Dépannage Rapide"

---

## 📊 Récapitulatif des Technologies

### Services
- **SOAP:** ASP.NET Web Services (asmx) - .NET Framework 4.7.2
- **REST:** WCF avec WebServiceHostFactory - .NET Framework 4.7.2

### Clients
- **SOAP:** Console .NET 6.0 avec System.ServiceModel
- **REST:** Console .NET 6.0 avec WebClient et Newtonsoft.Json

### Déploiement
- **Serveur:** IIS (Internet Information Services)
- **Configuration:** web.config, application pools

### Formats
- **SOAP:** XML (SOAP envelope)
- **REST:** XML (GET) et JSON (POST/PUT/DELETE)

---

## ✅ Checklist Complète du Projet

### Fichiers créés
- [x] 4 projets (2 services + 2 clients)
- [x] 6 fichiers de documentation
- [x] 2 scripts PowerShell

### Fonctionnalités
- [x] Service SOAP avec Add et Sub
- [x] Client SOAP fonctionnel
- [x] Service REST avec CRUD complet
- [x] Client REST avec menu interactif
- [x] Déploiement automatique
- [x] Tests automatiques

### Documentation
- [x] README complet
- [x] Guide de démarrage rapide
- [x] Notes théoriques détaillées
- [x] Exemples de requêtes
- [x] Structure du projet
- [x] Index de navigation

---

## 🎓 Objectifs Pédagogiques Atteints

### Savoirs
- ✅ Comprendre les services web SOAP et REST
- ✅ Connaître les différences et cas d'usage
- ✅ Maîtriser les concepts d'architecture distribuée

### Savoir-faire
- ✅ Créer un service web SOAP (asmx)
- ✅ Créer un service web REST (WCF)
- ✅ Développer des clients pour consommer ces services
- ✅ Déployer sur IIS
- ✅ Tester et déboguer

### Savoir-être
- ✅ Autonomie dans le développement
- ✅ Capacité à rechercher et résoudre des problèmes
- ✅ Rigueur dans la documentation

---

## 🌐 Ressources Externes

### Documentation Microsoft
- [ASP.NET Web Services](https://docs.microsoft.com/en-us/aspnet/web-forms/)
- [WCF Documentation](https://docs.microsoft.com/en-us/dotnet/framework/wcf/)
- [IIS Documentation](https://docs.microsoft.com/en-us/iis/)

### Tutoriels
- [RESTful API Best Practices](https://restfulapi.net/)
- [SOAP vs REST](https://www.guru99.com/comparison-between-web-services.html)

### Outils
- [Postman](https://www.postman.com/) - Test d'APIs
- [SoapUI](https://www.soapui.org/) - Test de services SOAP
- [Fiddler](https://www.telerik.com/fiddler) - Débogage HTTP

---

## 📞 Support

Pour toute question sur ce TP:
1. Consultez d'abord la documentation appropriée
2. Vérifiez les sections de dépannage
3. Testez avec les scripts fournis
4. Contactez votre enseignant si nécessaire

---

## 📝 Notes de Version

**Version:** 1.0  
**Date:** Décembre 2024  
**Auteur:** Projet TP8 - ENSA S9  
**Technologie:** .NET Framework 4.7.2 + .NET 6.0

---

**Bon apprentissage et bonne programmation! 🚀**
