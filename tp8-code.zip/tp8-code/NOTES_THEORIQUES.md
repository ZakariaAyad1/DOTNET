# Notes Théoriques - Services Web SOAP et REST

## Table des Matières
1. [Introduction aux Services Web](#1-introduction-aux-services-web)
2. [Services Web SOAP](#2-services-web-soap)
3. [Services Web REST](#3-services-web-rest)
4. [Comparaison SOAP vs REST](#4-comparaison-soap-vs-rest)
5. [Attributs C# pour les Services Web](#5-attributs-c-pour-les-services-web)
6. [Architectures et Bonnes Pratiques](#6-architectures-et-bonnes-pratiques)

---

## 1. Introduction aux Services Web

### Définition
Les **Services Web** sont des composants logiciels permettant à des applications de communiquer entre elles via le réseau, indépendamment des plateformes et des langages de programmation.

### Caractéristiques Principales
- **Interopérabilité:** Fonctionne sur différentes plateformes (Windows, Linux, Mac)
- **Standards ouverts:** HTTP, XML, JSON
- **Découplage:** Client et serveur indépendants
- **Réutilisabilité:** Même service pour plusieurs clients

### Technologies de Base
- **HTTP/HTTPS:** Protocole de transport
- **XML/JSON:** Formats de données
- **WSDL:** Description des services (SOAP)
- **WADL/OpenAPI:** Description des APIs (REST)

---

## 2. Services Web SOAP

### 2.1 Principes Fondamentaux

**SOAP** (Simple Object Access Protocol) est un protocole de messagerie basé sur XML pour l'échange d'informations structurées.

#### Architecture
```
┌─────────┐                    ┌─────────┐
│ Client  │ ─── SOAP Request ──▶│ Service │
│         │                    │         │
│ (Proxy) │ ◀── SOAP Response ─│ (asmx)  │
└─────────┘                    └─────────┘
```

### 2.2 Structure d'un Message SOAP

```xml
<?xml version="1.0"?>
<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Header>
    <!-- Métadonnées optionnelles (authentification, etc.) -->
  </soap:Header>
  <soap:Body>
    <!-- Données de la requête ou de la réponse -->
    <MethodName xmlns="namespace">
      <param1>valeur1</param1>
      <param2>valeur2</param2>
    </MethodName>
  </soap:Body>
</soap:Envelope>
```

### 2.3 Composants SOAP en .NET

#### Service SOAP (serveur)
```csharp
[WebService(Namespace = "http://example.com/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class MonService : WebService
{
    [WebMethod(Description = "Description de la méthode")]
    public int MaMethode(int param1, int param2)
    {
        return param1 + param2;
    }
}
```

#### Directive .asmx
```xml
<%@ WebService Language="C#" 
    CodeBehind="~/App_Code/Service.cs" 
    Class="Service" %>
```

### 2.4 WSDL (Web Services Description Language)

Le **WSDL** décrit l'interface du service web:
- Les méthodes disponibles
- Les paramètres et types de retour
- Les protocoles de communication
- L'adresse du service

**Accès au WSDL:** `http://localhost/Service.asmx?wsdl`

### 2.5 Proxy Client

Le **Proxy** est une classe générée automatiquement qui:
- Encapsule les appels SOAP
- Sérialise/désérialise les messages XML
- Gère la communication réseau

```csharp
// Utilisation du proxy
ServiceSoapClient client = new ServiceSoapClient();
int resultat = client.Add(10, 5);
```

### 2.6 Avantages et Inconvénients

**Avantages:**
- ✅ Standard bien défini (WS-*)
- ✅ Support transactionnel (WS-Transaction)
- ✅ Sécurité avancée (WS-Security)
- ✅ Fiabilité (WS-ReliableMessaging)
- ✅ Typage fort via WSDL
- ✅ Indépendant du transport (HTTP, SMTP, TCP)

**Inconvénients:**
- ❌ XML verbeux (plus lourd)
- ❌ Plus complexe à implémenter
- ❌ Performances moindres
- ❌ Moins adapté au web moderne

---

## 3. Services Web REST

### 3.1 Principes Fondamentaux

**REST** (Representational State Transfer) est un style architectural pour les systèmes distribués, basé sur les principes du web.

#### Contraintes REST
1. **Architecture Client-Serveur:** Séparation des responsabilités
2. **Sans état (Stateless):** Chaque requête est indépendante
3. **Cacheable:** Les réponses peuvent être mises en cache
4. **Interface uniforme:** Utilisation des méthodes HTTP standard
5. **Système en couches:** Architecture modulaire
6. **Code à la demande (optionnel):** Exécution de code côté client

### 3.2 Ressources et URIs

Tout est une **ressource** identifiée par une **URI**.

```
Ressource: Clients
├─ GET    /clients          → Liste tous les clients
├─ GET    /clients/{id}     → Récupère un client
├─ POST   /clients          → Crée un client
├─ PUT    /clients/{id}     → Modifie un client
└─ DELETE /clients/{id}     → Supprime un client
```

### 3.3 Méthodes HTTP

| Méthode | Opération | Idempotent | Safe |
|---------|-----------|------------|------|
| **GET**    | Lecture   | ✅ Oui     | ✅ Oui |
| **POST**   | Création  | ❌ Non     | ❌ Non |
| **PUT**    | Modification complète | ✅ Oui | ❌ Non |
| **PATCH**  | Modification partielle | ❌ Non | ❌ Non |
| **DELETE** | Suppression | ✅ Oui | ❌ Non |

- **Idempotent:** Plusieurs appels identiques produisent le même résultat
- **Safe:** Ne modifie pas l'état du serveur

### 3.4 WCF REST en .NET

#### Contrat de Service (Interface)
```csharp
[ServiceContract]
public interface IClient
{
    [OperationContract]
    [WebGet(UriTemplate = "clients", 
            ResponseFormat = WebMessageFormat.Json)]
    List<Client> GetClients();
    
    [OperationContract]
    [WebGet(UriTemplate = "clients/{id}")]
    Client GetClient(string id);
    
    [OperationContract]
    [WebInvoke(Method = "POST", UriTemplate = "clients",
               RequestFormat = WebMessageFormat.Json,
               ResponseFormat = WebMessageFormat.Json)]
    string AddClient(Client client);
}
```

#### Contrat de Données
```csharp
[DataContract]
public class Client
{
    [DataMember]
    public int Id { get; set; }
    
    [DataMember]
    public string Nom { get; set; }
}
```

#### Fichier .svc
```xml
<%@ ServiceHost Language="C#" 
    Service="Namespace.Client"
    Factory="System.ServiceModel.Activation.WebServiceHostFactory" %>
```

**Important:** L'attribut `Factory` active le mode REST sans configuration WCF.

### 3.5 Formats de Données

#### XML
```xml
<Client>
    <Id>1</Id>
    <Nom>Dupont</Nom>
    <Adresse>123 Rue</Adresse>
</Client>
```

#### JSON
```json
{
    "Id": 1,
    "Nom": "Dupont",
    "Adresse": "123 Rue"
}
```

### 3.6 Codes de Statut HTTP

| Code | Signification | Usage |
|------|--------------|-------|
| **200** | OK | Requête réussie (GET, PUT) |
| **201** | Created | Ressource créée (POST) |
| **204** | No Content | Succès sans contenu (DELETE) |
| **400** | Bad Request | Requête invalide |
| **401** | Unauthorized | Non authentifié |
| **403** | Forbidden | Accès interdit |
| **404** | Not Found | Ressource introuvable |
| **500** | Internal Server Error | Erreur serveur |

### 3.7 Avantages et Inconvénients

**Avantages:**
- ✅ Léger et performant
- ✅ Format JSON compact
- ✅ Facile à comprendre et utiliser
- ✅ Cache HTTP natif
- ✅ Idéal pour le web et mobile
- ✅ Pas besoin de proxy

**Inconvénients:**
- ❌ Pas de standard strict
- ❌ Sécurité à gérer manuellement
- ❌ Pas de support transactionnel intégré
- ❌ Pas de contrat formel (mais OpenAPI/Swagger)

---

## 4. Comparaison SOAP vs REST

### 4.1 Tableau Comparatif

| Aspect | SOAP | REST |
|--------|------|------|
| **Type** | Protocole | Style architectural |
| **Format** | XML uniquement | XML, JSON, HTML, texte |
| **Transport** | HTTP, SMTP, TCP, etc. | Principalement HTTP/HTTPS |
| **Contrat** | WSDL (formel) | WADL/OpenAPI (optionnel) |
| **Méthodes** | Noms personnalisés | Méthodes HTTP standard |
| **Taille** | Lourd (XML verbeux) | Léger (JSON compact) |
| **Performance** | Plus lent | Plus rapide |
| **Cache** | Difficile | Natif (HTTP) |
| **Sécurité** | WS-Security intégré | HTTPS + authentification |
| **État** | Peut être stateful | Stateless (principe REST) |
| **Complexité** | Élevée | Faible |
| **Outils** | Proxy automatique | Requêtes HTTP simples |

### 4.2 Quand Utiliser SOAP?

✅ **Utilisez SOAP pour:**
- Applications d'entreprise complexes
- Transactions distribuées (WS-Transaction)
- Sécurité avancée requise (WS-Security)
- Fiabilité garantie (WS-ReliableMessaging)
- Contrat formel nécessaire
- Communication non-HTTP

**Exemples:** Systèmes bancaires, ERP, systèmes de paiement

### 4.3 Quand Utiliser REST?

✅ **Utilisez REST pour:**
- APIs web publiques
- Applications mobiles
- Microservices
- Intégrations simples
- Performance critique
- Développement rapide

**Exemples:** APIs sociales (Twitter, Facebook), APIs cloud (AWS, Azure)

---

## 5. Attributs C# pour les Services Web

### 5.1 Attributs SOAP (asmx)

#### `[WebService]`
Marque une classe comme service web.

```csharp
[WebService(
    Namespace = "http://example.com/",
    Name = "MonService",
    Description = "Description du service"
)]
public class Service : WebService { }
```

**Propriétés:**
- `Namespace`: Espace de noms XML (évite les conflits)
- `Name`: Nom du service dans le WSDL
- `Description`: Documentation du service

#### `[WebMethod]`
Expose une méthode comme opération du service.

```csharp
[WebMethod(
    Description = "Additionne deux nombres",
    EnableSession = true,
    CacheDuration = 60,
    BufferResponse = true
)]
public int Add(int a, int b) { return a + b; }
```

**Propriétés:**
- `Description`: Documentation de la méthode
- `EnableSession`: Active la gestion de session
- `CacheDuration`: Durée de cache en secondes
- `BufferResponse`: Buffer la réponse avant envoi

#### `[WebServiceBinding]`
Spécifie la conformité aux standards.

```csharp
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
```

### 5.2 Attributs REST (WCF)

#### `[ServiceContract]`
Définit un contrat de service (interface).

```csharp
[ServiceContract(
    Namespace = "http://example.com/",
    Name = "IClient"
)]
public interface IClient { }
```

#### `[OperationContract]`
Définit une opération du contrat.

```csharp
[OperationContract]
[WebGet(UriTemplate = "clients/{id}")]
Client GetClient(string id);
```

#### `[WebGet]`
Mappe une opération à HTTP GET.

```csharp
[WebGet(
    UriTemplate = "clients/{id}",
    ResponseFormat = WebMessageFormat.Json,
    BodyStyle = WebMessageBodyStyle.Bare
)]
```

**Propriétés:**
- `UriTemplate`: Modèle d'URI (variables entre `{}`)
- `ResponseFormat`: Format de réponse (Xml, Json)
- `BodyStyle`: Style d'enveloppe (Bare, Wrapped)

#### `[WebInvoke]`
Mappe une opération à POST, PUT, DELETE.

```csharp
[WebInvoke(
    Method = "POST",
    UriTemplate = "clients",
    RequestFormat = WebMessageFormat.Json,
    ResponseFormat = WebMessageFormat.Json
)]
string AddClient(Client client);
```

**Propriétés:**
- `Method`: Méthode HTTP (POST, PUT, DELETE)
- `UriTemplate`: Modèle d'URI
- `RequestFormat`: Format de la requête
- `ResponseFormat`: Format de la réponse

#### `[DataContract]`
Définit un type sérialisable.

```csharp
[DataContract(
    Namespace = "http://example.com/data",
    Name = "Client"
)]
public class Client { }
```

#### `[DataMember]`
Marque un membre à sérialiser.

```csharp
[DataMember(
    Name = "Identifier",
    Order = 1,
    IsRequired = true
)]
public int Id { get; set; }
```

**Propriétés:**
- `Name`: Nom dans le XML/JSON
- `Order`: Ordre de sérialisation
- `IsRequired`: Membre obligatoire

---

## 6. Architectures et Bonnes Pratiques

### 6.1 Architecture en Couches

```
┌─────────────────────┐
│   Présentation      │  (Client: Console, Web, Mobile)
├─────────────────────┤
│   Service Web       │  (SOAP/REST)
├─────────────────────┤
│   Logique Métier    │  (Business Logic)
├─────────────────────┤
│   Accès aux Données │  (DAL: Entity Framework, ADO.NET)
├─────────────────────┤
│   Base de Données   │  (SQL Server, MySQL, etc.)
└─────────────────────┘
```

### 6.2 Bonnes Pratiques SOAP

1. **Namespace unique:** Utilisez un namespace basé sur votre domaine
2. **Documentation:** Ajoutez des descriptions aux méthodes
3. **Gestion des erreurs:** Utilisez SoapException
4. **Versioning:** Incluez la version dans le namespace
5. **Sécurité:** Utilisez HTTPS et WS-Security

```csharp
[WebService(Namespace = "http://votredomaine.com/2024/v1")]
[WebMethod(Description = "Description claire")]
public Result MaMethode(Param param)
{
    try
    {
        // Logique
    }
    catch (Exception ex)
    {
        throw new SoapException("Message d'erreur", 
            SoapException.ServerFaultCode, ex);
    }
}
```

### 6.3 Bonnes Pratiques REST

#### 1. Nommage des Ressources
- **Utilisez des noms (pas de verbes):** `/clients` pas `/getClients`
- **Pluriel pour les collections:** `/clients` pas `/client`
- **Minuscules:** `/clients` pas `/Clients`
- **Hiérarchie:** `/clients/1/orders` pour les sous-ressources

#### 2. Méthodes HTTP Appropriées
```
GET    /clients       → Liste
GET    /clients/1     → Détail
POST   /clients       → Création
PUT    /clients/1     → Modification complète
PATCH  /clients/1     → Modification partielle
DELETE /clients/1     → Suppression
```

#### 3. Codes de Statut
```csharp
// Création réussie
[WebInvoke(Method = "POST", ...)]
public Client AddClient(Client client)
{
    // Créer le client
    WebOperationContext.Current.OutgoingResponse.StatusCode = 
        HttpStatusCode.Created;
    WebOperationContext.Current.OutgoingResponse.Headers.Add(
        "Location", $"/clients/{client.Id}");
    return client;
}
```

#### 4. Versioning
- **URL:** `/api/v1/clients`
- **Header:** `Accept: application/vnd.company.v1+json`
- **Query:** `/clients?version=1`

#### 5. Pagination
```
GET /clients?page=2&size=50
GET /clients?offset=100&limit=50
```

#### 6. Filtrage et Tri
```
GET /clients?nom=Dupont
GET /clients?sort=nom,asc
GET /clients?fields=id,nom
```

#### 7. HATEOAS (Hypermedia)
```json
{
    "id": 1,
    "nom": "Dupont",
    "_links": {
        "self": "/clients/1",
        "orders": "/clients/1/orders",
        "delete": "/clients/1"
    }
}
```

### 6.4 Sécurité

#### SOAP
- **WS-Security:** Signatures et chiffrement XML
- **HTTPS:** Chiffrement du transport
- **Authentification:** Username/Password token

#### REST
- **HTTPS:** Obligatoire
- **OAuth 2.0:** Authentification moderne
- **JWT:** JSON Web Tokens
- **API Keys:** Pour les APIs simples
- **CORS:** Cross-Origin Resource Sharing

```csharp
// Exemple: Vérification d'API Key
if (WebOperationContext.Current.IncomingRequest
    .Headers["X-API-Key"] != "votre-cle")
{
    WebOperationContext.Current.OutgoingResponse.StatusCode = 
        HttpStatusCode.Unauthorized;
    return null;
}
```

### 6.5 Gestion des Erreurs REST

```csharp
// Retourner une erreur structurée
public class ErrorResponse
{
    public int Code { get; set; }
    public string Message { get; set; }
    public List<string> Details { get; set; }
}

[WebGet(UriTemplate = "clients/{id}")]
public Client GetClient(string id)
{
    try
    {
        int clientId = int.Parse(id);
        var client = _repository.GetById(clientId);
        
        if (client == null)
        {
            WebOperationContext.Current.OutgoingResponse.StatusCode = 
                HttpStatusCode.NotFound;
            return null;
        }
        
        return client;
    }
    catch (FormatException)
    {
        WebOperationContext.Current.OutgoingResponse.StatusCode = 
            HttpStatusCode.BadRequest;
        return null;
    }
}
```

---

## 7. Évolution des Technologies

### Historique .NET
1. **ASP.NET Web Services (asmx)** - 2002
   - Première implémentation SOAP en .NET
   - Simple mais limitée

2. **WCF (Windows Communication Foundation)** - 2006
   - Unifie SOAP, REST, TCP, MSMQ
   - Flexible mais complexe

3. **ASP.NET Web API** - 2012
   - Spécialisé pour REST
   - Moderne, basé sur MVC

4. **ASP.NET Core Web API** - 2016+
   - Cross-platform
   - Haute performance
   - Standard actuel

### Tendances Actuelles
- **GraphQL:** Alternative à REST
- **gRPC:** RPC moderne (Google)
- **Microservices:** Architecture distribuée
- **Serverless:** Functions as a Service (FaaS)
- **API Gateway:** Centralisation des APIs

---

## Conclusion

### Points Clés

**SOAP:**
- Protocole mature et standardisé
- Adapté aux systèmes d'entreprise
- Plus complexe mais plus complet

**REST:**
- Style architectural simple
- Standard de facto pour le web
- Léger et performant

**Choix:**
- **Entreprise/Complexe:** SOAP
- **Web/Mobile/API:** REST
- **Mixte:** Utilisez les deux selon les besoins

### Ressources Supplémentaires
- [REST API Tutorial](https://restfulapi.net/)
- [SOAP Specifications](https://www.w3.org/TR/soap/)
- [WCF Documentation](https://docs.microsoft.com/en-us/dotnet/framework/wcf/)
- [ASP.NET Core Web API](https://docs.microsoft.com/en-us/aspnet/core/web-api/)
