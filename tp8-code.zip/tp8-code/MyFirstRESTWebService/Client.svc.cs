using System;
using System.Collections.Generic;
using System.Linq;

namespace MyFirstRESTWebService
{
    /// <summary>
    /// Implémentation du service de gestion des clients
    /// </summary>
    public class Client : IClient
    {
        // Liste statique pour simuler une base de données
        private static List<InfoClients> clientsDB = new List<InfoClients>
        {
            new InfoClients { IdClient = 1, Nom = "Dupont", Adresse = "123 Rue de Paris" },
            new InfoClients { IdClient = 2, Nom = "Martin", Adresse = "456 Avenue des Champs" },
            new InfoClients { IdClient = 3, Nom = "Bernard", Adresse = "789 Boulevard Saint-Michel" },
            new InfoClients { IdClient = 4, Nom = "Dubois", Adresse = "321 Rue de la République" },
            new InfoClients { IdClient = 5, Nom = "Thomas", Adresse = "654 Avenue Victor Hugo" }
        };

        /// <summary>
        /// Récupère la liste de tous les clients
        /// </summary>
        public string GetClients()
        {
            try
            {
                var clientNames = clientsDB.Select(c => c.Nom).ToArray();
                return string.Join(", ", clientNames);
            }
            catch (Exception ex)
            {
                return $"Erreur: {ex.Message}";
            }
        }

        /// <summary>
        /// Récupère les informations d'un client spécifique
        /// </summary>
        public InfoClients GetInfoClient(string idClient)
        {
            try
            {
                int id = Convert.ToInt32(idClient);
                var client = clientsDB.FirstOrDefault(c => c.IdClient == id);

                if (client == null)
                {
                    return new InfoClients
                    {
                        IdClient = 0,
                        Nom = "Client non trouvé",
                        Adresse = ""
                    };
                }

                return client;
            }
            catch (Exception ex)
            {
                return new InfoClients
                {
                    IdClient = 0,
                    Nom = $"Erreur: {ex.Message}",
                    Adresse = ""
                };
            }
        }

        /// <summary>
        /// Ajoute un nouveau client
        /// </summary>
        public string AddClient(InfoClients client)
        {
            try
            {
                if (client == null)
                    return "Erreur: Client null";

                // Générer un nouvel ID
                int newId = clientsDB.Any() ? clientsDB.Max(c => c.IdClient) + 1 : 1;
                client.IdClient = newId;

                clientsDB.Add(client);
                return $"Client ajouté avec succès. ID: {newId}";
            }
            catch (Exception ex)
            {
                return $"Erreur lors de l'ajout: {ex.Message}";
            }
        }

        /// <summary>
        /// Met à jour un client existant
        /// </summary>
        public string UpdateClient(string idClient, InfoClients client)
        {
            try
            {
                int id = Convert.ToInt32(idClient);
                var existingClient = clientsDB.FirstOrDefault(c => c.IdClient == id);

                if (existingClient == null)
                    return $"Erreur: Client avec ID {id} non trouvé";

                existingClient.Nom = client.Nom;
                existingClient.Adresse = client.Adresse;

                return $"Client {id} mis à jour avec succès";
            }
            catch (Exception ex)
            {
                return $"Erreur lors de la mise à jour: {ex.Message}";
            }
        }

        /// <summary>
        /// Supprime un client
        /// </summary>
        public string DeleteClient(string idClient)
        {
            try
            {
                int id = Convert.ToInt32(idClient);
                var client = clientsDB.FirstOrDefault(c => c.IdClient == id);

                if (client == null)
                    return $"Erreur: Client avec ID {id} non trouvé";

                clientsDB.Remove(client);
                return $"Client {id} supprimé avec succès";
            }
            catch (Exception ex)
            {
                return $"Erreur lors de la suppression: {ex.Message}";
            }
        }
    }
}
