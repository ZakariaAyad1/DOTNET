using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace MyFirstRESTWebService
{
    /// <summary>
    /// Contrat de service pour la gestion des clients
    /// </summary>
    [ServiceContract]
    public interface IClient
    {
        /// <summary>
        /// Récupère la liste de tous les clients
        /// </summary>
        /// <returns>Liste des noms de clients</returns>
        [OperationContract]
        [WebGet(UriTemplate = "clients", ResponseFormat = WebMessageFormat.Xml)]
        string GetClients();

        /// <summary>
        /// Récupère les informations d'un client spécifique
        /// </summary>
        /// <param name="idClient">Identifiant du client</param>
        /// <returns>Informations détaillées du client</returns>
        [OperationContract]
        [WebGet(UriTemplate = "clients/{idClient}", ResponseFormat = WebMessageFormat.Xml)]
        InfoClients GetInfoClient(string idClient);

        /// <summary>
        /// Ajoute un nouveau client
        /// </summary>
        /// <param name="client">Informations du nouveau client</param>
        /// <returns>Message de confirmation</returns>
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "clients",
                   RequestFormat = WebMessageFormat.Json,
                   ResponseFormat = WebMessageFormat.Json)]
        string AddClient(InfoClients client);

        /// <summary>
        /// Met à jour un client existant
        /// </summary>
        /// <param name="idClient">Identifiant du client à modifier</param>
        /// <param name="client">Nouvelles informations du client</param>
        /// <returns>Message de confirmation</returns>
        [OperationContract]
        [WebInvoke(Method = "PUT", UriTemplate = "clients/{idClient}",
                   RequestFormat = WebMessageFormat.Json,
                   ResponseFormat = WebMessageFormat.Json)]
        string UpdateClient(string idClient, InfoClients client);

        /// <summary>
        /// Supprime un client
        /// </summary>
        /// <param name="idClient">Identifiant du client à supprimer</param>
        /// <returns>Message de confirmation</returns>
        [OperationContract]
        [WebInvoke(Method = "DELETE", UriTemplate = "clients/{idClient}",
                   ResponseFormat = WebMessageFormat.Json)]
        string DeleteClient(string idClient);
    }

    /// <summary>
    /// Contrat de données pour les informations client
    /// </summary>
    [DataContract]
    public class InfoClients
    {
        [DataMember]
        public int IdClient { get; set; }

        [DataMember]
        public string Nom { get; set; }

        [DataMember]
        public string Adresse { get; set; }
    }
}
