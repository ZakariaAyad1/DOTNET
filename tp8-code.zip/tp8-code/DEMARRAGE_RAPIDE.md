# 🚀 Guide de Démarrage Rapide - TP8 Services Web

## Option 1: Déploiement Automatique (Recommandé)

### Étape 1: Déployer les services
```powershell
# Ouvrir PowerShell en tant qu'Administrateur
# Se placer dans le dossier du projet
cd "c:\Users\LENOVO\Documents\Ensa\s9\Technologie d'Entreprise\dot-net\tp\tp8\tp8-code"

# Déployer tous les services
.\Deploy.ps1 -All
```

### Étape 2: Tester le service REST
```powershell
# Toujours en mode Administrateur
.\TestRESTService.ps1
```

### Étape 3: Tester dans le navigateur
- **SOAP:** http://localhost/MyFirstWebService/Service.asmx
- **REST:** http://localhost/MyFirstRESTWebService/Client.svc/clients

---

## Option 2: Déploiement Manuel

### A. Service SOAP

#### 1. Via Visual Studio
```
1. Ouvrir Visual Studio
2. Fichier → Ouvrir → Site Web
3. Sélectionner: MyFirstWebService
4. Clic droit sur Service.asmx → "Afficher dans le navigateur"
5. Tester les méthodes Add et Sub
```

#### 2. Via IIS
```powershell
# PowerShell en Administrateur
# Copier les fichiers
Copy-Item -Path "MyFirstWebService\*" `
          -Destination "C:\inetpub\wwwroot\MyFirstWebService" `
          -Recurse

# Créer l'application
Import-Module WebAdministration
New-WebApplication -Site "Default Web Site" `
                   -Name "MyFirstWebService" `
                   -PhysicalPath "C:\inetpub\wwwroot\MyFirstWebService" `
                   -ApplicationPool "DefaultAppPool"
```

Tester: http://localhost/MyFirstWebService/Service.asmx

---

### B. Service REST

#### 1. Via Visual Studio
```
1. Ouvrir Visual Studio
2. Fichier → Ouvrir → Site Web
3. Sélectionner: MyFirstRESTWebService
4. Clic droit sur Client.svc → "Afficher dans le navigateur"
5. Aller à: http://localhost:PORT/Client.svc/clients
```

#### 2. Via IIS
```powershell
# PowerShell en Administrateur
# Copier les fichiers
Copy-Item -Path "MyFirstRESTWebService\*" `
          -Destination "C:\inetpub\wwwroot\MyFirstRESTWebService" `
          -Recurse

# Créer l'application
New-WebApplication -Site "Default Web Site" `
                   -Name "MyFirstRESTWebService" `
                   -PhysicalPath "C:\inetpub\wwwroot\MyFirstRESTWebService" `
                   -ApplicationPool "DefaultAppPool"
```

Tester: http://localhost/MyFirstRESTWebService/Client.svc/clients

---

## Option 3: Exécution des Clients

### Client SOAP

#### Étape 1: Ajouter la référence de service
```powershell
cd MyFirstWebServiceClient

# Option A: Via dotnet-svcutil
dotnet tool install --global dotnet-svcutil
dotnet-svcutil http://localhost/MyFirstWebService/Service.asmx?wsdl `
               -d ServiceReference `
               -n "*,MyFirstWebServiceClient.ServiceReference"

# Option B: Via Visual Studio
# Clic droit sur le projet → Ajouter → Référence de service
# URL: http://localhost/MyFirstWebService/Service.asmx
# Namespace: ServiceReference
```

#### Étape 2: Exécuter le client
```powershell
dotnet restore
dotnet build
dotnet run
```

---

### Client REST

```powershell
cd MyFirstRESTWebServiceClient

# Compiler et exécuter
dotnet restore
dotnet build
dotnet run
```

Le menu interactif s'affiche:
```
=== Client Service Web REST ===

Choisissez une option:
1. Afficher tous les clients (GET)
2. Afficher un client spécifique (GET avec paramètre)
3. Ajouter un client (POST)
4. Modifier un client (PUT)
5. Supprimer un client (DELETE)
0. Quitter
```

---

## Tests Rapides en PowerShell

### Service SOAP
```powershell
# Tester si le service est accessible
Invoke-WebRequest -Uri "http://localhost/MyFirstWebService/Service.asmx" -UseBasicParsing
```

### Service REST
```powershell
# GET - Liste des clients
Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" -Method GET

# GET - Client spécifique
Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1" -Method GET

# POST - Ajouter un client
$client = @{ Nom="Test"; Adresse="123 Rue Test" } | ConvertTo-Json
Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" `
                  -Method POST `
                  -ContentType "application/json" `
                  -Body $client
```

---

## Vérifications Système

### Vérifier IIS
```powershell
# Service IIS actif?
Get-Service W3SVC

# Démarrer si nécessaire
Start-Service W3SVC
```

### Vérifier les fonctionnalités Windows
```powershell
# Lister les fonctionnalités IIS
Get-WindowsOptionalFeature -Online | Where-Object { $_.FeatureName -like "*IIS*" }

# Lister les fonctionnalités WCF
Get-WindowsOptionalFeature -Online | Where-Object { $_.FeatureName -like "*WCF*" }
```

### Activer les fonctionnalités manquantes
```powershell
# IIS
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServer

# WCF HTTP Activation (important pour REST)
Enable-WindowsOptionalFeature -Online -FeatureName WCF-HTTP-Activation
Enable-WindowsOptionalFeature -Online -FeatureName WCF-Services45
```

---

## Résolution de Problèmes Courants

### Erreur: "Impossible de se connecter"
```powershell
# Vérifier qu'IIS écoute sur le port 80
netstat -ano | findstr :80

# Redémarrer IIS
iisreset
```

### Erreur 404 - Page non trouvée
```powershell
# Vérifier que les fichiers sont bien copiés
Test-Path "C:\inetpub\wwwroot\MyFirstWebService\Service.asmx"
Test-Path "C:\inetpub\wwwroot\MyFirstRESTWebService\Client.svc"

# Lister les applications IIS
Import-Module WebAdministration
Get-WebApplication -Site "Default Web Site"
```

### Erreur 500 - Erreur interne du serveur
```powershell
# Vérifier les logs d'événements
Get-EventLog -LogName Application -Source "ASP.NET*" -Newest 5

# Pour REST: Vérifier que system.serviceModel est supprimé de web.config
Select-String -Path "MyFirstRESTWebService\Web.config" -Pattern "system.serviceModel"
# (Ne doit rien retourner)
```

### Service REST ne répond pas aux requêtes
```powershell
# Vérifier l'activation WCF HTTP
dism /online /get-features | findstr /C:"WCF-HTTP-Activation"

# Si "Disabled", activer:
dism /online /enable-feature /featurename:WCF-HTTP-Activation
dism /online /enable-feature /featurename:WCF-Services45
```

---

## Commandes Utiles

### Nettoyer et redéployer
```powershell
# Supprimer les déploiements existants
Remove-Item "C:\inetpub\wwwroot\MyFirstWebService" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "C:\inetpub\wwwroot\MyFirstRESTWebService" -Recurse -Force -ErrorAction SilentlyContinue

# Redéployer
.\Deploy.ps1 -All
```

### Afficher la configuration IIS
```powershell
Import-Module WebAdministration

# Sites
Get-Website

# Applications
Get-WebApplication -Site "Default Web Site"

# Pools d'applications
Get-IISAppPool
```

### Logs et diagnostics
```powershell
# Logs IIS
Get-Content "C:\inetpub\logs\LogFiles\W3SVC1\*.log" | Select-Object -Last 20

# Logs d'application Windows
Get-EventLog -LogName Application -Newest 10 | Where-Object { $_.Source -like "*ASP*" -or $_.Source -like "*WCF*" }
```

---

## Points de Contrôle

Avant de tester, assurez-vous que:

- [ ] IIS est installé et démarré
- [ ] Les fonctionnalités WCF sont activées
- [ ] Les services sont déployés dans C:\inetpub\wwwroot
- [ ] Les applications IIS sont créées
- [ ] Le pare-feu n'est pas bloqué (port 80)
- [ ] Vous pouvez accéder aux URLs dans le navigateur

---

## Ressources

- **Documentation complète:** [README.md](README.md)
- **Exemples de requêtes:** [EXEMPLES_REQUETES.md](EXEMPLES_REQUETES.md)
- **Script de déploiement:** [Deploy.ps1](Deploy.ps1)
- **Script de test:** [TestRESTService.ps1](TestRESTService.ps1)

---

## Support

En cas de problème:
1. Consultez la section "Dépannage" dans [README.md](README.md)
2. Vérifiez les logs IIS et Windows
3. Testez avec les scripts PowerShell fournis
4. Utilisez les exemples de requêtes dans [EXEMPLES_REQUETES.md](EXEMPLES_REQUETES.md)
