# Script de test rapide pour le service REST
# Exécuter après avoir déployé le service

param(
    [string]$BaseUrl = "http://localhost/MyFirstRESTWebService/Client.svc"
)

Write-Host "=== Test du Service REST ===" -ForegroundColor Cyan
Write-Host "URL de base: $BaseUrl" -ForegroundColor Gray
Write-Host ""

function Test-Endpoint {
    param(
        [string]$Name,
        [string]$Method,
        [string]$Uri,
        [string]$Body = $null,
        [string]$ContentType = "application/json"
    )
    
    Write-Host "Test: $Name" -ForegroundColor Green
    Write-Host "  Method: $Method" -ForegroundColor Gray
    Write-Host "  URI: $Uri" -ForegroundColor Gray
    
    try {
        $params = @{
            Uri = $Uri
            Method = $Method
            ErrorAction = "Stop"
        }
        
        if ($Body) {
            $params.Add("ContentType", $ContentType)
            $params.Add("Body", $Body)
            Write-Host "  Body: $Body" -ForegroundColor Gray
        }
        
        $response = Invoke-RestMethod @params
        
        Write-Host "  ✓ Succès!" -ForegroundColor Green
        Write-Host "  Réponse: " -ForegroundColor Yellow -NoNewline
        
        if ($response -is [System.Xml.XmlDocument] -or $response -is [System.Xml.XmlElement]) {
            Write-Host $response.OuterXml -ForegroundColor Yellow
        } else {
            Write-Host $response -ForegroundColor Yellow
        }
        
        return $true
    }
    catch {
        Write-Host "  ✗ Échec!" -ForegroundColor Red
        Write-Host "  Erreur: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
    finally {
        Write-Host ""
    }
}

# Tests
$results = @()

# 1. GET - Liste des clients
$results += Test-Endpoint -Name "GET tous les clients" `
                          -Method "GET" `
                          -Uri "$BaseUrl/clients"

# 2. GET - Client spécifique (ID 1)
$results += Test-Endpoint -Name "GET client ID 1" `
                          -Method "GET" `
                          -Uri "$BaseUrl/clients/1"

# 3. GET - Client spécifique (ID 2)
$results += Test-Endpoint -Name "GET client ID 2" `
                          -Method "GET" `
                          -Uri "$BaseUrl/clients/2"

# 4. POST - Ajouter un client
$newClient = @{
    Nom = "Client Test $(Get-Date -Format 'HHmmss')"
    Adresse = "123 Rue de Test"
} | ConvertTo-Json

$results += Test-Endpoint -Name "POST ajouter un client" `
                          -Method "POST" `
                          -Uri "$BaseUrl/clients" `
                          -Body $newClient

# 5. PUT - Modifier un client
$updatedClient = @{
    Nom = "Client Modifié"
    Adresse = "456 Nouvelle Adresse"
} | ConvertTo-Json

$results += Test-Endpoint -Name "PUT modifier client ID 3" `
                          -Method "PUT" `
                          -Uri "$BaseUrl/clients/3" `
                          -Body $updatedClient

# 6. DELETE - Supprimer un client
$results += Test-Endpoint -Name "DELETE supprimer client ID 4" `
                          -Method "DELETE" `
                          -Uri "$BaseUrl/clients/4"

# 7. Vérification finale
$results += Test-Endpoint -Name "GET liste finale" `
                          -Method "GET" `
                          -Uri "$BaseUrl/clients"

# Résumé
Write-Host "=== Résumé des Tests ===" -ForegroundColor Cyan
$successCount = ($results | Where-Object { $_ -eq $true }).Count
$totalCount = $results.Count
$failCount = $totalCount - $successCount

Write-Host "Total: $totalCount tests" -ForegroundColor White
Write-Host "Succès: $successCount" -ForegroundColor Green
Write-Host "Échecs: $failCount" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Green" })

if ($failCount -gt 0) {
    Write-Host ""
    Write-Host "Conseils de dépannage:" -ForegroundColor Yellow
    Write-Host "1. Vérifiez que le service est déployé: Test-Path 'C:\inetpub\wwwroot\MyFirstRESTWebService\Client.svc'" -ForegroundColor Gray
    Write-Host "2. Vérifiez IIS: Get-Service W3SVC" -ForegroundColor Gray
    Write-Host "3. Redémarrez IIS: iisreset" -ForegroundColor Gray
    Write-Host "4. Vérifiez l'URL dans votre navigateur: $BaseUrl/clients" -ForegroundColor Gray
}

Write-Host ""
