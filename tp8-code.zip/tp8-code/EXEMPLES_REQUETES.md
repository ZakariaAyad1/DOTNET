# Exemples de Requêtes pour Tester les Services Web

## Service Web SOAP

### Via Navigateur Web
1. Ouvrir: http://localhost/MyFirstWebService/Service.asmx
2. Cliquer sur une méthode (Add ou Sub)
3. Entrer les paramètres
4. Cliquer "Invoke"

### Via PowerShell (SOAP Request manuelle)

```powershell
# Préparer la requête SOAP pour Add
$soapRequest = @"
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
               xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
               xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <Add xmlns="http://tempuri.org/">
      <a>10</a>
      <b>5</b>
    </Add>
  </soap:Body>
</soap:Envelope>
"@

# Envoyer la requête
$response = Invoke-WebRequest -Uri "http://localhost/MyFirstWebService/Service.asmx" `
                               -Method POST `
                               -ContentType "text/xml; charset=utf-8" `
                               -Body $soapRequest `
                               -Headers @{"SOAPAction"="http://tempuri.org/Add"}

# Afficher la réponse
$response.Content
```

---

## Service Web REST

### 1. GET - Liste de tous les clients

#### PowerShell
```powershell
Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" -Method GET
```

#### cURL
```bash
curl http://localhost/MyFirstRESTWebService/Client.svc/clients
```

#### Navigateur
```
http://localhost/MyFirstRESTWebService/Client.svc/clients
```

**Réponse attendue:**
```
Dupont, Martin, Bernard, Dubois, Thomas
```

---

### 2. GET - Informations d'un client spécifique

#### PowerShell
```powershell
# Client avec ID 1
$response = Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1" -Method GET
$response
```

#### cURL
```bash
curl http://localhost/MyFirstRESTWebService/Client.svc/clients/1
```

#### Navigateur
```
http://localhost/MyFirstRESTWebService/Client.svc/clients/1
```

**Réponse attendue (XML):**
```xml
<InfoClients xmlns="http://schemas.datacontract.org/2004/07/MyFirstRESTWebService">
    <Adresse>123 Rue de Paris</Adresse>
    <IdClient>1</IdClient>
    <Nom>Dupont</Nom>
</InfoClients>
```

---

### 3. POST - Ajouter un nouveau client

#### PowerShell
```powershell
$newClient = @{
    Nom = "Leblanc"
    Adresse = "999 Avenue des Tests"
} | ConvertTo-Json

$response = Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" `
                               -Method POST `
                               -ContentType "application/json" `
                               -Body $newClient

Write-Host $response
```

#### cURL
```bash
curl -X POST http://localhost/MyFirstRESTWebService/Client.svc/clients \
  -H "Content-Type: application/json" \
  -d "{\"Nom\":\"Leblanc\",\"Adresse\":\"999 Avenue des Tests\"}"
```

#### PowerShell (alternative avec Invoke-WebRequest)
```powershell
$body = @{
    Nom = "Leblanc"
    Adresse = "999 Avenue des Tests"
} | ConvertTo-Json

$response = Invoke-WebRequest -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" `
                              -Method POST `
                              -ContentType "application/json" `
                              -Body $body

$response.Content
```

**Réponse attendue:**
```json
"Client ajouté avec succès. ID: 6"
```

---

### 4. PUT - Modifier un client existant

#### PowerShell
```powershell
$updatedClient = @{
    Nom = "Dupont Modifié"
    Adresse = "Nouvelle Adresse 123"
} | ConvertTo-Json

$response = Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1" `
                               -Method PUT `
                               -ContentType "application/json" `
                               -Body $updatedClient

Write-Host $response
```

#### cURL
```bash
curl -X PUT http://localhost/MyFirstRESTWebService/Client.svc/clients/1 \
  -H "Content-Type: application/json" \
  -d "{\"Nom\":\"Dupont Modifié\",\"Adresse\":\"Nouvelle Adresse 123\"}"
```

**Réponse attendue:**
```json
"Client 1 mis à jour avec succès"
```

---

### 5. DELETE - Supprimer un client

#### PowerShell
```powershell
$response = Invoke-RestMethod -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1" `
                               -Method DELETE

Write-Host $response
```

#### cURL
```bash
curl -X DELETE http://localhost/MyFirstRESTWebService/Client.svc/clients/1
```

**Réponse attendue:**
```json
"Client 1 supprimé avec succès"
```

---

## Script PowerShell Complet de Test

```powershell
# Script de test complet pour le service REST
$baseUrl = "http://localhost/MyFirstRESTWebService/Client.svc"

Write-Host "=== Test du Service REST ===" -ForegroundColor Cyan
Write-Host ""

# 1. GET - Liste des clients
Write-Host "1. GET - Liste de tous les clients" -ForegroundColor Green
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients" -Method GET
    Write-Host "Résultat: $response" -ForegroundColor Yellow
} catch {
    Write-Host "Erreur: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# 2. GET - Client spécifique
Write-Host "2. GET - Client avec ID 2" -ForegroundColor Green
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients/2" -Method GET
    Write-Host "ID: $($response.IdClient)" -ForegroundColor Yellow
    Write-Host "Nom: $($response.Nom)" -ForegroundColor Yellow
    Write-Host "Adresse: $($response.Adresse)" -ForegroundColor Yellow
} catch {
    Write-Host "Erreur: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# 3. POST - Ajouter un client
Write-Host "3. POST - Ajouter un nouveau client" -ForegroundColor Green
try {
    $newClient = @{
        Nom = "Test Client"
        Adresse = "123 Test Avenue"
    } | ConvertTo-Json
    
    $response = Invoke-RestMethod -Uri "$baseUrl/clients" `
                                  -Method POST `
                                  -ContentType "application/json" `
                                  -Body $newClient
    Write-Host "Résultat: $response" -ForegroundColor Yellow
} catch {
    Write-Host "Erreur: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# 4. PUT - Modifier un client
Write-Host "4. PUT - Modifier le client ID 3" -ForegroundColor Green
try {
    $updatedClient = @{
        Nom = "Bernard Modifié"
        Adresse = "Nouvelle Adresse"
    } | ConvertTo-Json
    
    $response = Invoke-RestMethod -Uri "$baseUrl/clients/3" `
                                  -Method PUT `
                                  -ContentType "application/json" `
                                  -Body $updatedClient
    Write-Host "Résultat: $response" -ForegroundColor Yellow
} catch {
    Write-Host "Erreur: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# 5. DELETE - Supprimer un client
Write-Host "5. DELETE - Supprimer le client ID 5" -ForegroundColor Green
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients/5" -Method DELETE
    Write-Host "Résultat: $response" -ForegroundColor Yellow
} catch {
    Write-Host "Erreur: $($_.Exception.Message)" -ForegroundColor Red
}
Write-Host ""

# 6. Vérification finale - Liste mise à jour
Write-Host "6. Vérification - Liste finale des clients" -ForegroundColor Green
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/clients" -Method GET
    Write-Host "Résultat: $response" -ForegroundColor Yellow
} catch {
    Write-Host "Erreur: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Tests terminés ===" -ForegroundColor Cyan
```

---

## Test avec Postman

Si vous utilisez Postman:

### Configuration
1. Créer une nouvelle collection "TP8 Services Web"
2. Ajouter les requêtes ci-dessous

### Requête GET - Liste
- **Method:** GET
- **URL:** `http://localhost/MyFirstRESTWebService/Client.svc/clients`
- **Headers:** (aucun requis)

### Requête GET - Détail
- **Method:** GET
- **URL:** `http://localhost/MyFirstRESTWebService/Client.svc/clients/1`
- **Headers:** (aucun requis)

### Requête POST - Créer
- **Method:** POST
- **URL:** `http://localhost/MyFirstRESTWebService/Client.svc/clients`
- **Headers:** 
  - `Content-Type: application/json`
- **Body (raw JSON):**
```json
{
    "Nom": "Nouveau Client",
    "Adresse": "123 Rue Exemple"
}
```

### Requête PUT - Modifier
- **Method:** PUT
- **URL:** `http://localhost/MyFirstRESTWebService/Client.svc/clients/1`
- **Headers:** 
  - `Content-Type: application/json`
- **Body (raw JSON):**
```json
{
    "Nom": "Client Modifié",
    "Adresse": "456 Nouvelle Adresse"
}
```

### Requête DELETE - Supprimer
- **Method:** DELETE
- **URL:** `http://localhost/MyFirstRESTWebService/Client.svc/clients/1`
- **Headers:** (aucun requis)

---

## Vérification des Services

### Vérifier qu'IIS fonctionne
```powershell
Get-Service W3SVC
```

### Vérifier les applications IIS
```powershell
Import-Module WebAdministration
Get-WebApplication -Site "Default Web Site"
```

### Tester la connectivité
```powershell
# SOAP
Test-NetConnection -ComputerName localhost -Port 80
Invoke-WebRequest -Uri "http://localhost/MyFirstWebService/Service.asmx" -UseBasicParsing

# REST
Invoke-WebRequest -Uri "http://localhost/MyFirstRESTWebService/Client.svc" -UseBasicParsing
```

---

## Dépannage Rapide

### Erreur 404 - Service non trouvé
```powershell
# Vérifier que les fichiers sont bien déployés
Test-Path "C:\inetpub\wwwroot\MyFirstRESTWebService\Client.svc"

# Redémarrer IIS
iisreset
```

### Erreur 500 - Erreur interne du serveur
```powershell
# Vérifier les logs IIS
Get-EventLog -LogName Application -Source "ASP.NET*" -Newest 10

# Activer les erreurs détaillées (temporairement)
# Modifier Web.config:
# <system.web>
#   <customErrors mode="Off"/>
# </system.web>
```

### Service REST ne répond pas
```powershell
# Vérifier que la fonctionnalité WCF HTTP Activation est activée
dism /online /get-features | findstr WCF

# Activer si nécessaire
dism /online /enable-feature /featurename:WCF-HTTP-Activation
```
