# Instructions pour ajouter la référence de service SOAP

## Étape 1: Démarrer le service web
1. Ouvrir le dossier `MyFirstWebService` dans Visual Studio
2. Cliquer droit sur `Service.asmx` et choisir "Afficher dans le navigateur"
3. Noter l'URL affichée (ex: http://localhost:xxxx/Service.asmx)

## Étape 2: Ajouter la référence dans le client
1. Ouvrir le projet `MyFirstWebServiceClient` dans Visual Studio
2. Cliquer droit sur le projet → "Ajouter" → "Référence de service"
3. Cliquer sur "Services WCF"
4. Dans "Adresse", entrer l'URL du service: http://localhost:xxxx/Service.asmx
5. Cliquer "OK" pour découvrir le service
6. Dans "Namespace", entrer: ServiceReference
7. Cliquer "OK"

## Alternative via ligne de commande:
```powershell
# Installer l'outil dotnet-svcutil
dotnet tool install --global dotnet-svcutil

# Générer le proxy (remplacer l'URL par celle de votre service)
dotnet-svcutil http://localhost:xxxx/Service.asmx?wsdl -d ServiceReference -n "*,MyFirstWebServiceClient.ServiceReference"
```

## Note:
Le fichier Program.cs utilise déjà le namespace `MyFirstWebServiceClient.ServiceReference` pour le proxy généré.
