using System;
using MyFirstWebServiceClient.ServiceReference;

namespace MyFirstWebServiceClient
{
    /// <summary>
    /// Client console pour consommer le service web SOAP
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== Client Service Web SOAP ===\n");

            try
            {
                // Créer un objet de la classe Proxy (ServiceSoapClient)
                ServiceSoapClient client = new ServiceSoapClient(
                    ServiceSoapClient.EndpointConfiguration.ServiceSoap);

                // Test de la méthode Add
                Console.WriteLine("Test de la méthode Add:");
                Console.Write("Entrez le premier nombre: ");
                int a = int.Parse(Console.ReadLine() ?? "0");

                Console.Write("Entrez le deuxième nombre: ");
                int b = int.Parse(Console.ReadLine() ?? "0");

                int resultAdd = client.AddAsync(a, b).Result;
                Console.WriteLine($"Résultat de l'addition: {a} + {b} = {resultAdd}\n");

                // Test de la méthode Sub
                Console.WriteLine("Test de la méthode Sub:");
                int resultSub = client.SubAsync(a, b).Result;
                Console.WriteLine($"Résultat de la soustraction: {a} - {b} = {resultSub}\n");

                // Fermer le client
                client.CloseAsync().Wait();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur: {ex.Message}");
            }

            Console.WriteLine("\nAppuyez sur une touche pour quitter...");
            Console.ReadKey();
        }
    }
}
