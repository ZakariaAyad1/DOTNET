using System;
using System.Web.Services;

/// <summary>
/// Service Web SOAP pour les opérations arithmétiques de base
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service()
    {
        // Constructor
    }

    /// <summary>
    /// Effectue l'addition de deux entiers
    /// </summary>
    /// <param name="a">Premier entier</param>
    /// <param name="b">Deuxième entier</param>
    /// <returns>La somme de a et b</returns>
    [WebMethod(Description = "Effectue l'addition de deux entiers")]
    public int Add(int a, int b)
    {
        return a + b;
    }

    /// <summary>
    /// Effectue la soustraction de deux entiers
    /// </summary>
    /// <param name="a">Premier entier</param>
    /// <param name="b">Deuxième entier</param>
    /// <returns>La différence entre a et b</returns>
    [WebMethod(Description = "Effectue la soustraction de deux entiers")]
    public int Sub(int a, int b)
    {
        return a - b;
    }
}
