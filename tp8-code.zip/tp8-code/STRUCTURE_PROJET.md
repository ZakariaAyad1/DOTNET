# 📁 Structure Complète du Projet

## Vue d'Ensemble

```
tp8-code/
│
├── 📄 README.md                          # Documentation principale
├── 📄 DEMARRAGE_RAPIDE.md                # Guide de démarrage
├── 📄 NOTES_THEORIQUES.md                # Concepts théoriques
├── 📄 EXEMPLES_REQUETES.md               # Exemples de tests
├── 📄 Deploy.ps1                         # Script de déploiement
├── 📄 TestRESTService.ps1                # Script de test
│
├── 📂 MyFirstWebService/                 # ⚡ SERVICE SOAP
│   ├── 📄 Service.asmx                   # Point d'entrée SOAP
│   ├── 📄 Web.config                     # Configuration
│   └── 📂 App_Code/
│       └── 📄 Service.cs                 # Implémentation (Add, Sub)
│
├── 📂 MyFirstWebServiceClient/           # 🖥️ CLIENT SOAP
│   ├── 📄 Program.cs                     # Application console
│   ├── 📄 MyFirstWebServiceClient.csproj # Fichier projet
│   └── 📄 README.md                      # Instructions référence
│
├── 📂 MyFirstRESTWebService/             # ⚡ SERVICE REST
│   ├── 📄 Client.svc                     # Point d'entrée REST
│   ├── 📄 Client.svc.cs                  # Implémentation
│   ├── 📄 IClient.cs                     # Contrat de service
│   └── 📄 Web.config                     # Configuration (sans system.serviceModel)
│
└── 📂 MyFirstRESTWebServiceClient/       # 🖥️ CLIENT REST
    ├── 📄 Program.cs                     # Application console avec menu
    └── 📄 MyFirstRESTWebServiceClient.csproj
```

---

## 📂 MyFirstWebService (Service SOAP)

### Structure Détaillée
```
MyFirstWebService/
│
├── 📄 Service.asmx
│   ├─ Directive: <%@ WebService Language="C#" ... %>
│   ├─ Point d'entrée HTTP
│   └─ URL: http://localhost/MyFirstWebService/Service.asmx
│
├── 📄 Web.config
│   ├─ Configuration ASP.NET
│   ├─ Compilation settings
│   └─ Target Framework
│
└── 📂 App_Code/
    └── 📄 Service.cs
        ├─ Classe: Service : WebService
        ├─ Attribut: [WebService(Namespace = "...")]
        ├─ Méthode: [WebMethod] int Add(int a, int b)
        └─ Méthode: [WebMethod] int Sub(int a, int b)
```

### Fichiers Clés

#### Service.asmx
```
Type: Fichier ASP.NET Handler
But: Point d'entrée du service SOAP
Contenu: Directive de service web
WSDL: Service.asmx?wsdl
```

#### Service.cs
```
Langage: C#
Hérite: System.Web.Services.WebService
Méthodes: Add, Sub (marquées [WebMethod])
Namespace: http://tempuri.org/
```

#### Web.config
```
Type: Configuration XML
Sections: <system.web>, <compilation>
Target Framework: 4.7.2
```

### Déploiement IIS
```
Chemin: C:\inetpub\wwwroot\MyFirstWebService\
Structure:
  ├── Service.asmx
  ├── Web.config
  └── App_Code\
      └── Service.cs

Application IIS: Default Web Site/MyFirstWebService
Pool: DefaultAppPool
```

---

## 📂 MyFirstWebServiceClient (Client SOAP)

### Structure Détaillée
```
MyFirstWebServiceClient/
│
├── 📄 MyFirstWebServiceClient.csproj
│   ├─ Target: net6.0
│   ├─ OutputType: Exe
│   └─ Packages: System.ServiceModel.*
│
├── 📄 Program.cs
│   ├─ Namespace: MyFirstWebServiceClient
│   ├─ Classe: Program
│   ├─ Utilise: ServiceReference.ServiceSoapClient
│   ├─ Appelle: AddAsync(), SubAsync()
│   └─ Gère: Entrées utilisateur et affichage
│
├── 📄 README.md
│   └─ Instructions pour ajouter la référence
│
└── 📂 ServiceReference/ (généré)
    ├── Reference.cs (Proxy généré)
    └── Service.wsdl (Description du service)
```

### Génération du Proxy

#### Méthode 1: Visual Studio
```
1. Clic droit sur projet
2. Ajouter → Référence de service
3. URL: http://localhost:xxxx/Service.asmx
4. Namespace: ServiceReference
5. OK → Génération automatique
```

#### Méthode 2: dotnet-svcutil
```powershell
dotnet tool install --global dotnet-svcutil
dotnet-svcutil http://localhost/MyFirstWebService/Service.asmx?wsdl `
  -d ServiceReference `
  -n "*,MyFirstWebServiceClient.ServiceReference"
```

### Utilisation
```csharp
// Créer le client proxy
ServiceSoapClient client = new ServiceSoapClient(
    ServiceSoapClient.EndpointConfiguration.ServiceSoap);

// Appeler les méthodes (asynchrones)
int result = await client.AddAsync(10, 5);

// Fermer la connexion
await client.CloseAsync();
```

---

## 📂 MyFirstRESTWebService (Service REST)

### Structure Détaillée
```
MyFirstRESTWebService/
│
├── 📄 Client.svc
│   ├─ Directive: <%@ ServiceHost ... %>
│   ├─ Service: MyFirstRESTWebService.Client
│   ├─ Factory: WebServiceHostFactory (Important!)
│   └─ URL: http://localhost/MyFirstRESTWebService/Client.svc
│
├── 📄 IClient.cs (Interface - Contrat)
│   ├─ [ServiceContract]
│   ├─ [OperationContract] + [WebGet]
│   │   ├─ GetClients() → /clients
│   │   └─ GetInfoClient(id) → /clients/{id}
│   ├─ [OperationContract] + [WebInvoke(Method="POST")]
│   │   └─ AddClient() → POST /clients
│   ├─ [OperationContract] + [WebInvoke(Method="PUT")]
│   │   └─ UpdateClient() → PUT /clients/{id}
│   ├─ [OperationContract] + [WebInvoke(Method="DELETE")]
│   │   └─ DeleteClient() → DELETE /clients/{id}
│   └─ [DataContract] InfoClients
│       ├─ [DataMember] IdClient
│       ├─ [DataMember] Nom
│       └─ [DataMember] Adresse
│
├── 📄 Client.svc.cs (Implémentation)
│   ├─ Classe: Client : IClient
│   ├─ Liste statique: clientsDB
│   ├─ Implémente: GetClients()
│   ├─ Implémente: GetInfoClient(string idClient)
│   ├─ Implémente: AddClient(InfoClients client)
│   ├─ Implémente: UpdateClient(string idClient, ...)
│   └─ Implémente: DeleteClient(string idClient)
│
└── 📄 Web.config
    ├─ <system.web> uniquement
    ├─ PAS de <system.serviceModel> (supprimé!)
    └─ Configuration IIS minimale
```

### Endpoints REST

#### Routes Disponibles
```
┌────────┬─────────────────────────┬──────────────────────┐
│ Méthode│ URL                     │ Action               │
├────────┼─────────────────────────┼──────────────────────┤
│ GET    │ /clients                │ Liste tous           │
│ GET    │ /clients/1              │ Détail client 1      │
│ POST   │ /clients                │ Créer nouveau        │
│ PUT    │ /clients/1              │ Modifier client 1    │
│ DELETE │ /clients/1              │ Supprimer client 1   │
└────────┴─────────────────────────┴──────────────────────┘
```

#### Formats
```
GET    → Retourne: XML
POST   → Envoie: JSON, Retourne: JSON
PUT    → Envoie: JSON, Retourne: JSON
DELETE → Retourne: JSON
```

### Configuration Spéciale

#### Factory dans Client.svc
```xml
Factory="System.ServiceModel.Activation.WebServiceHostFactory"
```
**Rôle:** Active le comportement REST sans configuration WCF

#### Web.config
```xml
<!-- NE PAS INCLURE <system.serviceModel> -->
<configuration>
  <system.web>
    <!-- Configuration ASP.NET uniquement -->
  </system.web>
</configuration>
```

### Données par Défaut
```csharp
clientsDB = new List<InfoClients>
{
    { IdClient = 1, Nom = "Dupont", Adresse = "123 Rue de Paris" },
    { IdClient = 2, Nom = "Martin", Adresse = "456 Avenue des Champs" },
    { IdClient = 3, Nom = "Bernard", Adresse = "789 Boulevard Saint-Michel" },
    { IdClient = 4, Nom = "Dubois", Adresse = "321 Rue de la République" },
    { IdClient = 5, Nom = "Thomas", Adresse = "654 Avenue Victor Hugo" }
};
```

---

## 📂 MyFirstRESTWebServiceClient (Client REST)

### Structure Détaillée
```
MyFirstRESTWebServiceClient/
│
├── 📄 MyFirstRESTWebServiceClient.csproj
│   ├─ Target: net6.0
│   ├─ OutputType: Exe
│   └─ Package: Newtonsoft.Json (pour JSON)
│
└── 📄 Program.cs
    ├─ Classe: InfoClients (modèle de données)
    │   ├─ IdClient: int
    │   ├─ Nom: string
    │   └─ Adresse: string
    │
    ├─ Classe: Program
    │   ├─ baseUrl: string (configuration)
    │   ├─ Main() → Menu interactif
    │   ├─ GetAllClients() → GET /clients
    │   ├─ GetClientById() → GET /clients/{id}
    │   ├─ AddClient() → POST /clients
    │   ├─ UpdateClient() → PUT /clients/{id}
    │   └─ DeleteClient() → DELETE /clients/{id}
    │
    └─ Utilise: System.Net.WebClient
        ├─ DownloadString() pour GET
        ├─ UploadString() pour POST/PUT/DELETE
        └─ Headers[ContentType] pour JSON
```

### Menu Interactif

```
=== Client Service Web REST ===

Choisissez une option:
1. Afficher tous les clients (GET)
   └─> Appelle: GET /clients
       Affiche: Liste des noms

2. Afficher un client spécifique (GET avec paramètre)
   └─> Demande: ID du client
       Appelle: GET /clients/{id}
       Parse: XML → XDocument
       Affiche: ID, Nom, Adresse

3. Ajouter un client (POST)
   └─> Demande: Nom, Adresse
       Sérialise: JSON (Newtonsoft.Json)
       Appelle: POST /clients
       Affiche: Message de confirmation

4. Modifier un client (PUT)
   └─> Demande: ID, Nouveau nom, Nouvelle adresse
       Sérialise: JSON
       Appelle: PUT /clients/{id}
       Affiche: Message de confirmation

5. Supprimer un client (DELETE)
   └─> Demande: ID
       Appelle: DELETE /clients/{id}
       Affiche: Message de confirmation

0. Quitter
```

### Utilisation de WebClient

#### GET Simple
```csharp
using (WebClient client = new WebClient())
{
    string result = client.DownloadString(url);
    Console.WriteLine(result);
}
```

#### GET avec Parsing XML
```csharp
string result = client.DownloadString(url);
XDocument doc = XDocument.Parse(result);
XNamespace ns = "http://schemas.datacontract.org/2004/07/...";
string nom = doc.Root?.Element(ns + "Nom")?.Value;
```

#### POST/PUT avec JSON
```csharp
client.Headers[HttpRequestHeader.ContentType] = "application/json";
string json = JsonConvert.SerializeObject(object);
string result = client.UploadString(url, "POST", json);
```

#### DELETE
```csharp
string result = client.UploadString(url, "DELETE", "");
```

---

## 🔄 Flux de Communication

### SOAP
```
┌─────────────┐                           ┌─────────────┐
│   Client    │                           │   Service   │
│  (Console)  │                           │   (asmx)    │
└─────────────┘                           └─────────────┘
       │                                         │
       │ 1. Appel méthode Add(10, 5)           │
       ├────────────────────────────────────────▶
       │                                         │
       │ 2. Proxy génère message SOAP XML       │
       │    <Add><a>10</a><b>5</b></Add>       │
       │                                         │
       │                                    3. Exécute
       │                                       Add(10,5)
       │                                         │
       │ 4. Retourne réponse SOAP XML           │
       │    <AddResponse><return>15</return>    │
       ◀────────────────────────────────────────┤
       │                                         │
       │ 5. Proxy parse XML → int result = 15   │
       │                                         │
```

### REST
```
┌─────────────┐                           ┌─────────────┐
│   Client    │                           │   Service   │
│  (Console)  │                           │   (WCF)     │
└─────────────┘                           └─────────────┘
       │                                         │
       │ 1. GET /clients/1                      │
       ├────────────────────────────────────────▶
       │    Host: localhost                      │
       │                                         │
       │                                    2. Execute
       │                                    GetInfoClient("1")
       │                                         │
       │ 3. HTTP 200 OK                         │
       │    Content-Type: text/xml               │
       │    <InfoClients>                        │
       │      <IdClient>1</IdClient>            │
       │      <Nom>Dupont</Nom>                 │
       │    </InfoClients>                       │
       ◀────────────────────────────────────────┤
       │                                         │
       │ 4. Parse XML → objet InfoClients       │
       │                                         │
```

---

## 🛠️ Scripts de Déploiement

### Deploy.ps1
```
Fonction: Déploiement automatique sur IIS
Prérequis: Privilèges administrateur

Étapes:
1. Check-IIS()
   └─ Vérifie si IIS est installé et démarré

2. Deploy-SOAPService()
   ├─ Copie MyFirstWebService → C:\inetpub\wwwroot\
   └─ Crée application IIS

3. Deploy-RESTService()
   ├─ Copie MyFirstRESTWebService → C:\inetpub\wwwroot\
   └─ Crée application IIS

4. Build-Clients()
   ├─ Compile MyFirstWebServiceClient
   └─ Compile MyFirstRESTWebServiceClient

Options:
  -SOAP : Déployer uniquement SOAP
  -REST : Déployer uniquement REST
  -All  : Déployer les deux (recommandé)
```

### TestRESTService.ps1
```
Fonction: Test automatique du service REST

Tests:
1. GET /clients (liste)
2. GET /clients/1 (détail)
3. GET /clients/2 (détail)
4. POST /clients (ajout)
5. PUT /clients/3 (modification)
6. DELETE /clients/4 (suppression)
7. GET /clients (vérification)

Résultat:
  Affiche: Nombre de tests réussis/échoués
  Suggère: Actions de dépannage si échec
```

---

## 📚 Fichiers de Documentation

### README.md
```
Contenu:
  - Structure du projet
  - Guide de démarrage complet
  - Instructions de déploiement (VS et IIS)
  - Utilisation des clients
  - Tests avec PowerShell et cURL
  - Dépannage détaillé
  - Concepts clés implémentés
```

### DEMARRAGE_RAPIDE.md
```
Contenu:
  - 3 options de déploiement
  - Commandes essentielles
  - Vérifications système
  - Résolution problèmes courants
  - Points de contrôle
```

### NOTES_THEORIQUES.md
```
Contenu:
  - Introduction aux services web
  - SOAP en détail (architecture, messages, composants)
  - REST en détail (principes, ressources, méthodes)
  - Comparaison SOAP vs REST
  - Attributs C# expliqués
  - Architectures et bonnes pratiques
```

### EXEMPLES_REQUETES.md
```
Contenu:
  - Exemples SOAP (PowerShell, navigateur)
  - Exemples REST (PowerShell, cURL, Postman)
  - Script de test complet
  - Vérifications et diagnostics
```

---

## 🎯 Points d'Entrée Principaux

### URLs des Services

#### SOAP
```
Service WSDL: http://localhost/MyFirstWebService/Service.asmx?wsdl
Service Home: http://localhost/MyFirstWebService/Service.asmx
Méthode Add:  http://localhost/MyFirstWebService/Service.asmx/Add
Méthode Sub:  http://localhost/MyFirstWebService/Service.asmx/Sub
```

#### REST
```
Service Home: http://localhost/MyFirstRESTWebService/Client.svc
Liste:        http://localhost/MyFirstRESTWebService/Client.svc/clients
Détail:       http://localhost/MyFirstRESTWebService/Client.svc/clients/1
```

### Exécution des Clients

#### Client SOAP
```powershell
cd MyFirstWebServiceClient
dotnet run

# Sortie:
# === Client Service Web SOAP ===
# Entrez le premier nombre: 10
# Entrez le deuxième nombre: 5
# Résultat de l'addition: 10 + 5 = 15
# Résultat de la soustraction: 10 - 5 = 5
```

#### Client REST
```powershell
cd MyFirstRESTWebServiceClient
dotnet run

# Sortie:
# === Client Service Web REST ===
# Choisissez une option:
# 1. Afficher tous les clients (GET)
# ...
```

---

## 📋 Checklist de Validation

### Service SOAP ✓
- [x] Service.asmx créé
- [x] Classe Service hérite de WebService
- [x] Attribut [WebService] configuré
- [x] Méthode Add() avec [WebMethod]
- [x] Méthode Sub() avec [WebMethod]
- [x] Web.config configuré
- [x] Déployable sur IIS
- [x] WSDL accessible

### Client SOAP ✓
- [x] Projet console .NET 6
- [x] Packages System.ServiceModel installés
- [x] Programme demande entrées utilisateur
- [x] Appelle méthodes Add et Sub
- [x] Affiche résultats
- [x] Instructions référence de service

### Service REST ✓
- [x] Client.svc créé avec Factory
- [x] Interface IClient avec [ServiceContract]
- [x] GET /clients implémenté
- [x] GET /clients/{id} implémenté
- [x] POST /clients implémenté
- [x] PUT /clients/{id} implémenté
- [x] DELETE /clients/{id} implémenté
- [x] InfoClients avec [DataContract]
- [x] Web.config sans system.serviceModel
- [x] Données de test par défaut

### Client REST ✓
- [x] Projet console .NET 6
- [x] Package Newtonsoft.Json installé
- [x] Menu interactif
- [x] GET tous les clients
- [x] GET client par ID
- [x] POST ajouter client
- [x] PUT modifier client
- [x] DELETE supprimer client
- [x] Parsing XML pour GET
- [x] Sérialisation JSON pour POST/PUT

### Documentation ✓
- [x] README.md complet
- [x] DEMARRAGE_RAPIDE.md
- [x] NOTES_THEORIQUES.md
- [x] EXEMPLES_REQUETES.md
- [x] STRUCTURE_PROJET.md (ce fichier)

### Scripts ✓
- [x] Deploy.ps1 (déploiement automatique)
- [x] TestRESTService.ps1 (tests automatiques)

---

## 🎓 Résumé pour l'Étudiant

### Ce que vous avez appris:

#### Concepts
- ✅ Services Web SOAP et REST
- ✅ Différences et cas d'usage
- ✅ Architecture client-serveur
- ✅ Protocoles HTTP et XML/JSON

#### Techniques SOAP
- ✅ Création service asmx
- ✅ Attributs [WebService] et [WebMethod]
- ✅ WSDL et contrats
- ✅ Génération et utilisation de Proxy

#### Techniques REST
- ✅ WCF avec WebServiceHostFactory
- ✅ Contrats avec [ServiceContract]
- ✅ Opérations GET/POST/PUT/DELETE
- ✅ [WebGet] et [WebInvoke]
- ✅ Contrats de données [DataContract]

#### Développement
- ✅ .NET Framework 4.7.2 (SOAP)
- ✅ .NET 6 (Clients modernes)
- ✅ Consommation de services
- ✅ Parsing XML et JSON

#### Déploiement
- ✅ IIS (Internet Information Services)
- ✅ Applications web ASP.NET
- ✅ Configuration web.config
- ✅ Tests et diagnostic

### Compétences acquises:
1. Créer et déployer des services web SOAP
2. Créer et déployer des services web REST
3. Développer des clients pour consommer ces services
4. Comprendre les différences architecturales
5. Tester et déboguer des services web
6. Déployer sur IIS

---

**Projet complet et fonctionnel! Bon apprentissage! 🚀**
