# Script de déploiement automatique des services web
# Exécuter en tant qu'administrateur

param(
    [switch]$SOAP,
    [switch]$REST,
    [switch]$All
)

$ErrorActionPreference = "Stop"

Write-Host "=== Script de Déploiement des Services Web ===" -ForegroundColor Cyan
Write-Host ""

# Vérifier les privilèges administrateur
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERREUR: Ce script nécessite des privilèges administrateur!" -ForegroundColor Red
    Write-Host "Faites clic droit sur le script et choisissez 'Exécuter en tant qu'administrateur'" -ForegroundColor Yellow
    exit 1
}

# Chemins
$scriptDir = $PSScriptRoot
$iisRoot = "C:\inetpub\wwwroot"

# Fonction pour déployer le service SOAP
function Deploy-SOAPService {
    Write-Host "[1/3] Déploiement du Service SOAP..." -ForegroundColor Green
    
    $sourcePath = Join-Path $scriptDir "MyFirstWebService"
    $destPath = Join-Path $iisRoot "MyFirstWebService"
    
    # Créer le dossier de destination
    if (Test-Path $destPath) {
        Write-Host "  → Suppression de l'ancien déploiement..." -ForegroundColor Yellow
        Remove-Item $destPath -Recurse -Force
    }
    
    Write-Host "  → Copie des fichiers..."
    Copy-Item -Path $sourcePath -Destination $destPath -Recurse
    
    # Créer l'application IIS
    Write-Host "  → Configuration IIS..."
    Import-Module WebAdministration -ErrorAction SilentlyContinue
    
    $appPath = "IIS:\Sites\Default Web Site\MyFirstWebService"
    if (Test-Path $appPath) {
        Remove-WebApplication -Site "Default Web Site" -Name "MyFirstWebService" -ErrorAction SilentlyContinue
    }
    
    New-WebApplication -Site "Default Web Site" -Name "MyFirstWebService" -PhysicalPath $destPath -ApplicationPool "DefaultAppPool"
    
    Write-Host "  ✓ Service SOAP déployé!" -ForegroundColor Green
    Write-Host "    URL: http://localhost/MyFirstWebService/Service.asmx" -ForegroundColor Cyan
    Write-Host ""
}

# Fonction pour déployer le service REST
function Deploy-RESTService {
    Write-Host "[2/3] Déploiement du Service REST..." -ForegroundColor Green
    
    $sourcePath = Join-Path $scriptDir "MyFirstRESTWebService"
    $destPath = Join-Path $iisRoot "MyFirstRESTWebService"
    
    # Créer le dossier de destination
    if (Test-Path $destPath) {
        Write-Host "  → Suppression de l'ancien déploiement..." -ForegroundColor Yellow
        Remove-Item $destPath -Recurse -Force
    }
    
    Write-Host "  → Copie des fichiers..."
    Copy-Item -Path $sourcePath -Destination $destPath -Recurse
    
    # Créer l'application IIS
    Write-Host "  → Configuration IIS..."
    Import-Module WebAdministration -ErrorAction SilentlyContinue
    
    $appPath = "IIS:\Sites\Default Web Site\MyFirstRESTWebService"
    if (Test-Path $appPath) {
        Remove-WebApplication -Site "Default Web Site" -Name "MyFirstRESTWebService" -ErrorAction SilentlyContinue
    }
    
    New-WebApplication -Site "Default Web Site" -Name "MyFirstRESTWebService" -PhysicalPath $destPath -ApplicationPool "DefaultAppPool"
    
    Write-Host "  ✓ Service REST déployé!" -ForegroundColor Green
    Write-Host "    URL: http://localhost/MyFirstRESTWebService/Client.svc" -ForegroundColor Cyan
    Write-Host "    Test: http://localhost/MyFirstRESTWebService/Client.svc/clients" -ForegroundColor Cyan
    Write-Host ""
}

# Fonction pour vérifier IIS
function Check-IIS {
    Write-Host "[0/3] Vérification d'IIS..." -ForegroundColor Green
    
    $iisService = Get-Service -Name W3SVC -ErrorAction SilentlyContinue
    if (-not $iisService) {
        Write-Host "  ✗ IIS n'est pas installé!" -ForegroundColor Red
        Write-Host "  → Activez IIS via: Panneau de configuration → Programmes → Activer/désactiver des fonctionnalités Windows" -ForegroundColor Yellow
        exit 1
    }
    
    if ($iisService.Status -ne "Running") {
        Write-Host "  → Démarrage d'IIS..."
        Start-Service W3SVC
    }
    
    Write-Host "  ✓ IIS est actif!" -ForegroundColor Green
    Write-Host ""
}

# Fonction pour compiler les clients
function Build-Clients {
    Write-Host "[3/3] Compilation des clients..." -ForegroundColor Green
    
    # Client SOAP
    $soapClientPath = Join-Path $scriptDir "MyFirstWebServiceClient"
    if (Test-Path $soapClientPath) {
        Write-Host "  → Compilation du client SOAP..."
        Push-Location $soapClientPath
        dotnet build --configuration Release > $null 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "    ✓ Client SOAP compilé" -ForegroundColor Green
        } else {
            Write-Host "    ⚠ Erreur compilation client SOAP (référence de service manquante?)" -ForegroundColor Yellow
        }
        Pop-Location
    }
    
    # Client REST
    $restClientPath = Join-Path $scriptDir "MyFirstRESTWebServiceClient"
    if (Test-Path $restClientPath) {
        Write-Host "  → Compilation du client REST..."
        Push-Location $restClientPath
        dotnet build --configuration Release > $null 2>&1
        if ($LASTEXITCODE -eq 0) {
            Write-Host "    ✓ Client REST compilé" -ForegroundColor Green
        } else {
            Write-Host "    ⚠ Erreur compilation client REST" -ForegroundColor Yellow
        }
        Pop-Location
    }
    
    Write-Host ""
}

# Exécution principale
try {
    Check-IIS
    
    if ($SOAP -or $All) {
        Deploy-SOAPService
    }
    
    if ($REST -or $All) {
        Deploy-RESTService
    }
    
    if (-not $SOAP -and -not $REST -and -not $All) {
        Write-Host "Usage: .\Deploy.ps1 [-SOAP] [-REST] [-All]" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Options:"
        Write-Host "  -SOAP  : Déployer uniquement le service SOAP"
        Write-Host "  -REST  : Déployer uniquement le service REST"
        Write-Host "  -All   : Déployer les deux services"
        Write-Host ""
        Write-Host "Exemple: .\Deploy.ps1 -All"
        exit 0
    }
    
    Build-Clients
    
    Write-Host "=== Déploiement terminé avec succès! ===" -ForegroundColor Green
    Write-Host ""
    Write-Host "Prochaines étapes:" -ForegroundColor Cyan
    Write-Host "1. Testez les services dans votre navigateur"
    Write-Host "2. Pour le client SOAP, ajoutez la référence de service (voir MyFirstWebServiceClient\README.md)"
    Write-Host "3. Exécutez les clients avec: dotnet run"
    
} catch {
    Write-Host ""
    Write-Host "ERREUR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Appuyez sur une touche pour continuer..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
