# TP8 - Création et Utilisation des Services Web en C#

Ce projet contient l'implémentation complète du TP sur les services web SOAP et REST en C#.

## Structure du Projet

```
tp8-code/
├── MyFirstWebService/              # Service Web SOAP (asmx)
│   ├── Service.asmx                # Point d'entrée du service SOAP
│   ├── App_Code/
│   │   └── Service.cs              # Implémentation (Add, Sub)
│   └── Web.config                  # Configuration du service
│
├── MyFirstWebServiceClient/        # Client Console SOAP
│   ├── Program.cs                  # Application console client
│   ├── MyFirstWebServiceClient.csproj
│   └── README.md                   # Instructions pour ajouter la référence
│
├── MyFirstRESTWebService/          # Service Web REST (WCF)
│   ├── Client.svc                  # Point d'entrée du service REST
│   ├── Client.svc.cs               # Implémentation du service
│   ├── IClient.cs                  # Contrat de service (interface)
│   └── Web.config                  # Configuration (sans system.serviceModel)
│
└── MyFirstRESTWebServiceClient/    # Client Console REST
    ├── Program.cs                  # Application console avec menu interactif
    └── MyFirstRESTWebServiceClient.csproj
```

## 🚀 Guide de Démarrage Rapide

### Prérequis

- **Visual Studio 2019/2022** avec:
  - Développement ASP.NET et web
  - Développement .NET Desktop
- **IIS (Internet Information Services)** activé sur Windows
- **.NET Framework 4.7.2+** et **.NET 6.0+**

### Activation d'IIS

1. Panneau de configuration → Programmes → Activer ou désactiver des fonctionnalités Windows
2. Cocher:
   - Internet Information Services
   - Services World Wide Web
   - Activation HTTP Windows Communication Foundation
   - Activation non-HTTP Windows Communication Foundation

---

## 📋 Partie 1: Service Web SOAP

### A. Configuration et Test du Service SOAP

#### Option 1: Via Visual Studio (Recommandé)

1. **Ouvrir le service dans Visual Studio:**
   ```
   Fichier → Ouvrir → Site Web → Sélectionner le dossier MyFirstWebService
   ```

2. **Démarrer le service:**
   - Clic droit sur `Service.asmx` → "Afficher dans le navigateur"
   - Le service démarre et affiche l'interface de test
   - Noter l'URL (ex: `http://localhost:12345/Service.asmx`)

3. **Tester les méthodes:**
   - Cliquer sur `Add` ou `Sub`
   - Entrer les paramètres
   - Cliquer sur "Invoke"

#### Option 2: Via IIS

1. **Déployer le service:**
   ```powershell
   # Créer le répertoire virtuel
   mkdir C:\inetpub\wwwroot\MyFirstWebService
   
   # Copier les fichiers
   Copy-Item -Path "MyFirstWebService\*" -Destination "C:\inetpub\wwwroot\MyFirstWebService" -Recurse
   ```

2. **Configurer IIS:**
   - Ouvrir le Gestionnaire IIS
   - Sites → Default Web Site → MyFirstWebService
   - Clic droit → Convertir en application
   - Pool d'applications: DefaultAppPool

3. **Tester:**
   - Naviguer vers: `http://localhost/MyFirstWebService/Service.asmx`

### B. Exécution du Client SOAP

1. **Configurer la référence de service:**

   **Méthode A: Via Visual Studio (GUI)**
   ```
   1. Ouvrir MyFirstWebServiceClient.csproj dans Visual Studio
   2. Clic droit sur le projet → Ajouter → Référence de service
   3. Entrer l'URL: http://localhost:12345/Service.asmx (votre URL)
   4. Namespace: ServiceReference
   5. Cliquer OK
   ```

   **Méthode B: Via ligne de commande**
   ```powershell
   # Installer l'outil
   dotnet tool install --global dotnet-svcutil
   
   # Se placer dans le dossier du client
   cd MyFirstWebServiceClient
   
   # Générer le proxy
   dotnet-svcutil http://localhost:12345/Service.asmx?wsdl `
     -d ServiceReference `
     -n "*,MyFirstWebServiceClient.ServiceReference"
   ```

2. **Compiler et exécuter:**
   ```powershell
   cd MyFirstWebServiceClient
   dotnet build
   dotnet run
   ```

3. **Utilisation:**
   - Entrer deux nombres
   - Le programme affiche les résultats de l'addition et de la soustraction

**Exemple de sortie:**
```
=== Client Service Web SOAP ===

Test de la méthode Add:
Entrez le premier nombre: 10
Entrez le deuxième nombre: 5
Résultat de l'addition: 10 + 5 = 15

Test de la méthode Sub:
Résultat de la soustraction: 10 - 5 = 5
```

---

## 📋 Partie 2: Service Web REST

### A. Configuration et Test du Service REST

#### Option 1: Via Visual Studio (Recommandé)

1. **Ouvrir le service:**
   ```
   Fichier → Ouvrir → Site Web → Sélectionner MyFirstRESTWebService
   ```

2. **Démarrer le service:**
   - Clic droit sur `Client.svc` → "Afficher dans le navigateur"
   - Noter l'URL de base (ex: `http://localhost:23456/Client.svc`)

3. **Tester les endpoints:**
   - **GET tous les clients:** 
     - URL: `http://localhost:23456/Client.svc/clients`
     - Retourne: Liste des noms des clients
   
   - **GET un client spécifique:**
     - URL: `http://localhost:23456/Client.svc/clients/1`
     - Retourne: XML avec les détails du client

#### Option 2: Via IIS

1. **Déployer:**
   ```powershell
   # Créer le répertoire
   mkdir C:\inetpub\wwwroot\MyFirstRESTWebService
   
   # Copier les fichiers
   Copy-Item -Path "MyFirstRESTWebService\*" `
             -Destination "C:\inetpub\wwwroot\MyFirstRESTWebService" `
             -Recurse
   ```

2. **Configurer IIS:**
   - Gestionnaire IIS → Sites → Default Web Site
   - Ajouter MyFirstRESTWebService comme application
   - Pool d'applications: DefaultAppPool

3. **Tester:**
   - `http://localhost/MyFirstRESTWebService/Client.svc/clients`

### B. Test avec des outils externes

#### Avec PowerShell:

```powershell
# GET - Liste des clients
Invoke-WebRequest -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" -Method GET

# GET - Client spécifique
Invoke-WebRequest -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1" -Method GET

# POST - Ajouter un client
$body = @{
    Nom = "Nouveau Client"
    Adresse = "123 Rue Exemple"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients" `
                  -Method POST `
                  -ContentType "application/json" `
                  -Body $body

# PUT - Modifier un client
$body = @{
    Nom = "Client Modifié"
    Adresse = "456 Nouvelle Adresse"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1" `
                  -Method PUT `
                  -ContentType "application/json" `
                  -Body $body

# DELETE - Supprimer un client
Invoke-WebRequest -Uri "http://localhost/MyFirstRESTWebService/Client.svc/clients/1" -Method DELETE
```

#### Avec cURL:

```bash
# GET - Liste des clients
curl http://localhost/MyFirstRESTWebService/Client.svc/clients

# GET - Client spécifique
curl http://localhost/MyFirstRESTWebService/Client.svc/clients/1

# POST - Ajouter un client
curl -X POST http://localhost/MyFirstRESTWebService/Client.svc/clients \
  -H "Content-Type: application/json" \
  -d '{"Nom":"Nouveau Client","Adresse":"123 Rue Exemple"}'

# PUT - Modifier un client
curl -X PUT http://localhost/MyFirstRESTWebService/Client.svc/clients/1 \
  -H "Content-Type: application/json" \
  -d '{"Nom":"Client Modifié","Adresse":"456 Nouvelle Adresse"}'

# DELETE - Supprimer un client
curl -X DELETE http://localhost/MyFirstRESTWebService/Client.svc/clients/1
```

### C. Exécution du Client REST

1. **Configurer l'URL:**
   - Ouvrir [Program.cs](MyFirstRESTWebServiceClient/Program.cs)
   - Modifier `baseUrl` si nécessaire:
   ```csharp
   private static string baseUrl = "http://localhost/MyFirstRESTWebService/Client.svc";
   ```

2. **Compiler et exécuter:**
   ```powershell
   cd MyFirstRESTWebServiceClient
   dotnet restore
   dotnet build
   dotnet run
   ```

3. **Menu interactif:**
   ```
   === Client Service Web REST ===

   Choisissez une option:
   1. Afficher tous les clients (GET)
   2. Afficher un client spécifique (GET avec paramètre)
   3. Ajouter un client (POST)
   4. Modifier un client (PUT)
   5. Supprimer un client (DELETE)
   0. Quitter
   ```

**Exemples d'utilisation:**

```
Votre choix: 1
--- Liste de tous les clients ---
Résultat: Dupont, Martin, Bernard, Dubois, Thomas

Votre choix: 2
Entrez l'ID du client: 1
--- Informations du client ---
ID: 1
Nom: Dupont
Adresse: 123 Rue de Paris

Votre choix: 3
--- Ajouter un nouveau client ---
Nom: Leblanc
Adresse: 999 Avenue Test
Résultat: Client ajouté avec succès. ID: 6
```

---

## 🔍 Concepts Clés Implémentés

### Services Web SOAP

- **Attributs utilisés:**
  - `[WebService]` : Définit la classe comme service web
  - `[WebMethod]` : Expose une méthode comme opération du service
  - `[WebServiceBinding]` : Conformité aux standards WS-I

- **Fonctionnement:**
  1. Le client génère un message SOAP XML
  2. Le Proxy (généré automatiquement) envoie la requête
  3. Le serveur exécute la méthode
  4. La réponse est retournée en SOAP XML
  5. Le Proxy décode automatiquement la réponse

### Services Web REST

- **Attributs utilisés:**
  - `[ServiceContract]` : Définit le contrat de service (interface)
  - `[OperationContract]` : Définit une opération du contrat
  - `[WebGet]` : Mappe à HTTP GET avec un template d'URI
  - `[WebInvoke]` : Mappe à POST, PUT, DELETE
  - `[DataContract]` : Définit un contrat de données
  - `[DataMember]` : Marque les propriétés à sérialiser

- **Architecture RESTful:**
  - GET `/clients` → Liste tous les clients
  - GET `/clients/{id}` → Récupère un client
  - POST `/clients` → Crée un client
  - PUT `/clients/{id}` → Modifie un client
  - DELETE `/clients/{id}` → Supprime un client

- **Formats:**
  - XML pour les réponses GET (facilement parsable)
  - JSON pour POST/PUT (format moderne et léger)

---

## 🛠️ Dépannage

### Problème: Service SOAP inaccessible

**Solution:**
```powershell
# Vérifier que le service ASP.NET est installé
dism /online /get-features | findstr IIS

# Enregistrer ASP.NET avec IIS
cd C:\Windows\Microsoft.NET\Framework64\v4.0.30319
.\aspnet_regiis.exe -i
```

### Problème: Service REST retourne 404

**Vérifications:**
1. Le fichier `Client.svc` existe
2. L'attribut `Factory="System.ServiceModel.Activation.WebServiceHostFactory"` est présent
3. La section `system.serviceModel` a été supprimée du `web.config`
4. Les fonctionnalités WCF sont activées dans Windows

### Problème: Erreur de référence de service

**Solution:**
```powershell
# Nettoyer et régénérer
dotnet clean
dotnet restore
dotnet build

# Régénérer le proxy
dotnet-svcutil http://localhost:PORT/Service.asmx?wsdl --force
```

### Problème: WebClient obsolète (.NET 6+)

Si vous préférez utiliser HttpClient moderne:
```csharp
using HttpClient client = new HttpClient();
var response = await client.GetStringAsync("http://localhost/...");
```

---

## 📚 Ressources Complémentaires

### Documentation Microsoft

- [ASP.NET Web Services (asmx)](https://docs.microsoft.com/en-us/aspnet/web-forms/overview/older-versions-getting-started/introduction/an-overview-of-inserting-updating-and-deleting-data-cs)
- [WCF REST Programming Model](https://docs.microsoft.com/en-us/dotnet/framework/wcf/feature-details/wcf-web-http-programming-model)
- [DataContract and DataMember](https://docs.microsoft.com/en-us/dotnet/framework/wcf/feature-details/using-data-contracts)

### Différences SOAP vs REST

| Aspect | SOAP | REST |
|--------|------|------|
| **Protocole** | Basé sur XML, protocole strict | Style architectural, flexible |
| **Format** | Toujours XML | XML, JSON, HTML, texte, etc. |
| **Complexité** | Plus complexe, nécessite WSDL | Plus simple, pas de WSDL |
| **Proxy** | Généré automatiquement | Pas nécessaire |
| **Performance** | Plus lourd (XML verbose) | Plus léger (JSON compact) |
| **Standards** | WS-Security, WS-Transaction, etc. | HTTP standard |
| **Cas d'usage** | Systèmes d'entreprise, transactions | API web modernes, mobile |

---

## ✅ Critères de Validation

- [x] Service SOAP créé avec méthodes Add et Sub
- [x] Client SOAP fonctionnel avec proxy généré
- [x] Service REST WCF créé avec contrat IClient
- [x] Opérations GET implémentées (liste et détail)
- [x] Opérations POST, PUT, DELETE implémentées
- [x] Client REST avec menu interactif complet
- [x] Gestion des erreurs dans les services et clients
- [x] Documentation complète du projet

---

## 👨‍💻 Auteur

Projet réalisé dans le cadre du TP8 - Technologies d'Entreprise  
ENSA - Semestre 9

## 📝 Licence

Projet éducatif - Libre d'utilisation pour l'apprentissage
