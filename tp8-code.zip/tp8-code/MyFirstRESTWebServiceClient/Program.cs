using System;
using System.Net;
using System.Text;
using System.Xml.Linq;
using Newtonsoft.Json;

namespace MyFirstRESTWebServiceClient
{
    /// <summary>
    /// Classe pour les informations client
    /// </summary>
    public class InfoClients
    {
        public int IdClient { get; set; }
        public string Nom { get; set; }
        public string Adresse { get; set; }
    }

    /// <summary>
    /// Client console pour consommer le service web REST
    /// </summary>
    class Program
    {
        private static string baseUrl = "http://localhost/MyFirstRESTWebService/Client.svc";

        static void Main(string[] args)
        {
            Console.WriteLine("=== Client Service Web REST ===\n");

            bool continuer = true;
            while (continuer)
            {
                Console.WriteLine("\nChoisissez une option:");
                Console.WriteLine("1. Afficher tous les clients (GET)");
                Console.WriteLine("2. Afficher un client spécifique (GET avec paramètre)");
                Console.WriteLine("3. Ajouter un client (POST)");
                Console.WriteLine("4. Modifier un client (PUT)");
                Console.WriteLine("5. Supprimer un client (DELETE)");
                Console.WriteLine("0. Quitter");
                Console.Write("\nVotre choix: ");

                string choix = Console.ReadLine();

                switch (choix)
                {
                    case "1":
                        GetAllClients();
                        break;
                    case "2":
                        GetClientById();
                        break;
                    case "3":
                        AddClient();
                        break;
                    case "4":
                        UpdateClient();
                        break;
                    case "5":
                        DeleteClient();
                        break;
                    case "0":
                        continuer = false;
                        break;
                    default:
                        Console.WriteLine("Choix invalide!");
                        break;
                }
            }

            Console.WriteLine("\nAu revoir!");
        }

        /// <summary>
        /// Récupère tous les clients
        /// </summary>
        static void GetAllClients()
        {
            Console.WriteLine("\n--- Liste de tous les clients ---");

            using (WebClient client = new WebClient())
            {
                try
                {
                    string url = $"{baseUrl}/clients";
                    string result = client.DownloadString(url);
                    Console.WriteLine($"Résultat: {result}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erreur: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Récupère un client par son ID
        /// </summary>
        static void GetClientById()
        {
            Console.Write("\nEntrez l'ID du client: ");
            string id = Console.ReadLine();

            using (WebClient client = new WebClient())
            {
                try
                {
                    string url = $"{baseUrl}/clients/{id}";
                    string result = client.DownloadString(url);

                    // Parser le XML
                    XDocument doc = XDocument.Parse(result);
                    XNamespace ns = "http://schemas.datacontract.org/2004/07/MyFirstRESTWebService";

                    var clientInfo = doc.Root;
                    string idClient = clientInfo?.Element(ns + "IdClient")?.Value ?? "N/A";
                    string nom = clientInfo?.Element(ns + "Nom")?.Value ?? "N/A";
                    string adresse = clientInfo?.Element(ns + "Adresse")?.Value ?? "N/A";

                    Console.WriteLine($"\n--- Informations du client ---");
                    Console.WriteLine($"ID: {idClient}");
                    Console.WriteLine($"Nom: {nom}");
                    Console.WriteLine($"Adresse: {adresse}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erreur: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Ajoute un nouveau client
        /// </summary>
        static void AddClient()
        {
            Console.WriteLine("\n--- Ajouter un nouveau client ---");
            Console.Write("Nom: ");
            string nom = Console.ReadLine();
            Console.Write("Adresse: ");
            string adresse = Console.ReadLine();

            InfoClients newClient = new InfoClients
            {
                Nom = nom,
                Adresse = adresse
            };

            using (WebClient client = new WebClient())
            {
                try
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string json = JsonConvert.SerializeObject(newClient);
                    string url = $"{baseUrl}/clients";

                    string result = client.UploadString(url, "POST", json);
                    Console.WriteLine($"Résultat: {result}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erreur: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Met à jour un client existant
        /// </summary>
        static void UpdateClient()
        {
            Console.WriteLine("\n--- Modifier un client ---");
            Console.Write("ID du client à modifier: ");
            string id = Console.ReadLine();
            Console.Write("Nouveau nom: ");
            string nom = Console.ReadLine();
            Console.Write("Nouvelle adresse: ");
            string adresse = Console.ReadLine();

            InfoClients updatedClient = new InfoClients
            {
                Nom = nom,
                Adresse = adresse
            };

            using (WebClient client = new WebClient())
            {
                try
                {
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";
                    string json = JsonConvert.SerializeObject(updatedClient);
                    string url = $"{baseUrl}/clients/{id}";

                    string result = client.UploadString(url, "PUT", json);
                    Console.WriteLine($"Résultat: {result}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erreur: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Supprime un client
        /// </summary>
        static void DeleteClient()
        {
            Console.WriteLine("\n--- Supprimer un client ---");
            Console.Write("ID du client à supprimer: ");
            string id = Console.ReadLine();

            using (WebClient client = new WebClient())
            {
                try
                {
                    string url = $"{baseUrl}/clients/{id}";
                    string result = client.UploadString(url, "DELETE", "");
                    Console.WriteLine($"Résultat: {result}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erreur: {ex.Message}");
                }
            }
        }
    }
}
