USE MyTestDB;
GO

IF OBJECT_ID('dbo.Commandes', 'U') IS NOT NULL
    DROP TABLE dbo.Commandes;
GO

IF OBJECT_ID('dbo.Clients', 'U') IS NOT NULL
    DROP TABLE dbo.Clients;
GO

CREATE TABLE Clients (
    NumClient INT PRIMARY KEY IDENTITY(1,1),
    NomClient VARCHAR(20) NOT NULL,
    PrenomClient VARCHAR(15) NOT NULL,
    AdresseClient VARCHAR(30) NOT NULL,
    NumTelClient VARCHAR(25) NULL
);
GO

CREATE TABLE Commandes (
    NumComd INT PRIMARY KEY IDENTITY(1,1),
    NumClient INT NOT NULL,
    DateComd DATE NOT NULL,
    EtatComd INT NOT NULL,
    CONSTRAINT FK_Commandes_Clients FOREIGN KEY (NumClient) REFERENCES Clients(NumClient)
);
GO

PRINT 'Tables Clients et Commandes créées avec succès';
