
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'MyTestDB')
BEGIN
    CREATE DATABASE MyTestDB;
    PRINT 'Base de données MyTestDB créée avec succès';
END
ELSE
BEGIN
    PRINT 'La base de données MyTestDB existe déjà';
END
GO

USE MyTestDB;
GO
