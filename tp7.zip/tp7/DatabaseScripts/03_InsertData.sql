USE MyTestDB;
GO

INSERT INTO Clients (NomClient, PrenomClient, AdresseClient, NumTelClient)
VALUES 
    ('ALAMI', 'Ahmed', 'Rue Mohamed V, Tétouan', '0612345678'),
    ('BENALI', 'Fatima', 'Avenue Hassan II, Tanger', '0623456789'),
    ('CHAKIR', 'Mohamed', 'Boulevard Moulay Youssef', '0634567890'),
    ('DOUIRI', 'Amina', 'Rue de la Liberté', NULL),
    ('EL FASSI', 'Karim', 'Avenue Mohammed VI', '0656789012');
GO

INSERT INTO Commandes (NumClient, DateComd, EtatComd)
VALUES 
    (1, '2025-01-15', 1),
    (1, '2025-02-20', 2),
    (2, '2025-01-10', 3),
    (3, '2025-03-05', 1),
    (4, '2025-02-28', 2),
    (5, '2025-03-12', 1);
GO

PRINT 'Données de test insérées avec succès';
PRINT 'Nombre de clients: ' + CAST((SELECT COUNT(*) FROM Clients) AS VARCHAR);
PRINT 'Nombre de commandes: ' + CAST((SELECT COUNT(*) FROM Commandes) AS VARCHAR);
