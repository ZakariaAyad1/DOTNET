# TP7 - Manipulation d'une BD SQLServer en C# **par**

#  **zakaria ayad**


## Description


Ce projet est une application console C# qui démontre la manipulation d'une base de données SQL Server (MyTestDB) avec les tables **Clients** et **Commandes**.

## Structure du projet

```
tp7/
├── DatabaseScripts/           # Scripts SQL pour la création de la BD
│   ├── 01_CreateDatabase.sql  # Création de la base MyTestDB
│   ├── 02_CreateTables.sql    # Création des tables Clients et Commandes
│   └── 03_InsertData.sql      # Insertion de données de test
│
└── SqlServerConnection/       # Application console C#
    ├── Program.cs             # Code principal
    └── SqlServerConnection.csproj
```

## Prérequis

- **SQL Server** (SQL Server Express ou version complète)
- **.NET 8.0 SDK** ou supérieur
- **Visual Studio 2022** ou **Visual Studio Code**

## Installation et Configuration

### 1. Créer la base de données

Exécutez les scripts SQL dans l'ordre suivant dans **SQL Server Management Studio (SSMS)** ou via **sqlcmd**:

```bash
sqlcmd -S (local) -E -i "DatabaseScripts\01_CreateDatabase.sql"
sqlcmd -S (local) -E -i "DatabaseScripts\02_CreateTables.sql"
sqlcmd -S (local) -E -i "DatabaseScripts\03_InsertData.sql"
```

Ou ouvrez chaque fichier dans SSMS et exécutez-les.

### 2. Configurer la chaîne de connexion

Dans [Program.cs](SqlServerConnection/Program.cs), modifiez la chaîne de connexion si nécessaire:

```csharp
private static string connectionString = 
    "integrated security=SSPI;" +
    "server=(local);" +              // Changez si votre serveur est différent
    "persist security info=False;" +
    "database=MyTestDB";
```

**Exemples de serveurs:**

- `(local)` ou `.` - Instance locale par défaut
- `(local)\SQLEXPRESS` - Instance SQL Server Express
- `localhost` - Serveur local
- `NOM_SERVEUR\INSTANCE` - Serveur distant

### 3. Compiler et exécuter l'application

#### Avec la ligne de commande:

```bash
cd SqlServerConnection
dotnet restore
dotnet build
dotnet run
```

#### Avec Visual Studio:

1. Ouvrez le fichier `.csproj`
2. Appuyez sur **F5** pour exécuter

## Fonctionnalités implémentées

### 1. Test de connexion

- Établissement de la connexion à MyTestDB
- Affichage des informations de connexion (serveur, base, version)

### 2. Consultation des données (SELECT)

- **AfficherClients()**: Affiche tous les clients avec gestion des valeurs NULL
- **AfficherCommandes()**: Affiche toutes les commandes

### 3. Opérations CRUD

#### INSERT (Ajout)

```csharp
AjouterClient("TAZI", "Sara", "Avenue des FAR, Rabat", "0667890123");
AjouterCommande(2, DateTime.Now, 1);
```

#### UPDATE (Modification)

```csharp
ModifierClient(1, "ALAMI", "Ahmed", "Nouvelle adresse", "0611111111");
```

#### DELETE (Suppression)

```csharp
SupprimerCommande(1);
```

## Concepts ADO.NET utilisés

### Classes principales

- **SqlConnection**: Gestion de la connexion à SQL Server
- **SqlCommand**: Exécution de requêtes SQL
- **SqlDataReader**: Lecture des résultats de SELECT

### Méthodes d'exécution

- **ExecuteReader()**: Pour les requêtes SELECT (retourne un SqlDataReader)
- **ExecuteNonQuery()**: Pour INSERT, UPDATE, DELETE (retourne le nombre de lignes affectées)
- **ExecuteScalar()**: Pour obtenir une seule valeur (non utilisé dans ce TP)

### Gestion des valeurs NULL

```csharp
if (!reader.IsDBNull(reader.GetOrdinal("NumTelClient")))
    numTel = (string)reader["NumTelClient"];
else
    numTel = "NULL";
```

### Paramètres SQL

Pour éviter les injections SQL, utilisez toujours des paramètres:

```csharp
cmd.Parameters.AddWithValue("@nom", nom);
cmd.Parameters.AddWithValue("@numTel", (object?)numTel ?? DBNull.Value);
```

## Structure de la base de données

### Table Clients

| Colonne       | Type        | Contrainte            |
| ------------- | ----------- | --------------------- |
| NumClient     | int         | PRIMARY KEY, IDENTITY |
| NomClient     | varchar(20) | NOT NULL              |
| PrenomClient  | varchar(15) | NOT NULL              |
| AdresseClient | varchar(30) | NOT NULL              |
| NumTelClient  | varchar(25) | NULL                  |

### Table Commandes

| Colonne   | Type | Contrainte                        |
| --------- | ---- | --------------------------------- |
| NumComd   | int  | PRIMARY KEY, IDENTITY             |
| NumClient | int  | FOREIGN KEY → Clients(NumClient) |
| DateComd  | date | NOT NULL                          |
| EtatComd  | int  | NOT NULL                          |

## Exemple de sortie

```
==============================================
TP7 - Manipulation d'une BD SQLServer en C#
==============================================

--- Test de connexion à MyTestDB ---
✓ Connexion établie avec succès
  - Serveur: (local)
  - Base de données: MyTestDB
  - Version SQL Server: 15.00.2000

--- Contenu de la table Clients ---
NumClient    NomClient            PrenomClient    AdresseClient                  NumTelClient   
-----------------------------------------------------------------------------------------------
1            ALAMI                Ahmed           Rue Mohamed V, Tétouan         0612345678   
2            BENALI               Fatima          Avenue Hassan II, Tanger       0623456789   
...
```

## Dépannage

### Erreur: "A network-related or instance-specific error"

- Vérifiez que SQL Server est en cours d'exécution
- Vérifiez le nom du serveur dans la chaîne de connexion
- Activez TCP/IP dans SQL Server Configuration Manager

### Erreur: "Cannot open database MyTestDB"

- Exécutez d'abord les scripts SQL de création de la base

### Erreur: "Login failed"

- Utilisez Windows Authentication (`integrated security=SSPI`)
- Ou ajoutez `User ID=...;Password=...` pour SQL Server Authentication

## Auteur

Travaux Pratiques - Technologies des Entreprises/.NET
ENSA Tétouan - 3ème année Génie Informatique
Année universitaire: 2025-2026
