using System;
using System.Data.SqlClient;

namespace SqlServerConnection
{
    class Program
    {
        private static string connectionString =
            "integrated security=SSPI;" +
            "server=(local);" +
            "persist security info=False;" +
            "database=MyTestDB";

        static void Main(string[] args)
        {
            Console.WriteLine("==============================================");
            Console.WriteLine("TP7 - Manipulation d'une BD SQLServer en C#");
            Console.WriteLine("==============================================\n");

            TestConnection();

            Console.WriteLine("\nAppuyez sur une touche pour continuer...");
            Console.ReadKey();

            AfficherClients();
            AfficherCommandes();

            Console.WriteLine("\nAppuyez sur une touche pour continuer...");
            Console.ReadKey();

            DemonstrationCRUD();

            Console.WriteLine("\n\nProgramme terminé. Appuyez sur une touche pour quitter...");
            Console.ReadKey();
        }

        static void TestConnection()
        {
            Console.WriteLine("--- Test de connexion à MyTestDB ---");

            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = connectionString;

            try
            {
                conn.Open();
                Console.WriteLine("✓ Connexion établie avec succès");
                Console.WriteLine($"  - Serveur: {conn.DataSource}");
                Console.WriteLine($"  - Base de données: {conn.Database}");
                Console.WriteLine($"  - Version SQL Server: {conn.ServerVersion}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Connexion échouée: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        static void AfficherClients()
        {
            Console.WriteLine("\n--- Contenu de la table Clients ---");

            SqlConnection conn = new SqlConnection(connectionString);
            string clientsSqlQuery = "SELECT * FROM Clients";

            try
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(clientsSqlQuery, conn);
                SqlDataReader reader = sqlCmd.ExecuteReader();

                if (reader != null)
                {
                    Console.WriteLine("{0,-12} {1,-20} {2,-15} {3,-30} {4,-15}",
                        "NumClient", "NomClient", "PrenomClient", "AdresseClient", "NumTelClient");
                    Console.WriteLine(new string('-', 95));

                    while (reader.Read())
                    {
                        string numTel;
                        if (!reader.IsDBNull(reader.GetOrdinal("NumTelClient")))
                            numTel = (string)reader["NumTelClient"];
                        else
                            numTel = "NULL";

                        Console.WriteLine("{0,-12} {1,-20} {2,-15} {3,-30} {4,-15}",
                            reader["NumClient"],
                            reader["NomClient"],
                            reader["PrenomClient"],
                            reader["AdresseClient"],
                            numTel);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de la lecture: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        static void AfficherCommandes()
        {
            Console.WriteLine("\n--- Contenu de la table Commandes ---");

            SqlConnection conn = new SqlConnection(connectionString);
            string commandesSqlQuery = "SELECT * FROM Commandes";

            try
            {
                conn.Open();

                SqlCommand sqlCmd = new SqlCommand(commandesSqlQuery, conn);
                SqlDataReader reader = sqlCmd.ExecuteReader();

                if (reader != null)
                {
                    Console.WriteLine("{0,-10} {1,-12} {2,-15} {3,-10}",
                        "NumComd", "NumClient", "DateComd", "EtatComd");
                    Console.WriteLine(new string('-', 50));

                    while (reader.Read())
                    {
                        Console.WriteLine("{0,-10} {1,-12} {2,-15:yyyy-MM-dd} {3,-10}",
                            reader["NumComd"],
                            reader["NumClient"],
                            reader["DateComd"],
                            reader["EtatComd"]);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de la lecture: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        static void DemonstrationCRUD()
        {
            Console.WriteLine("\n\n==============================================");
            Console.WriteLine("Démonstration des opérations CRUD");
            Console.WriteLine("==============================================");


            Console.WriteLine("\n--- 1. INSERT: Ajout d'un nouveau client ---");
            AjouterClient("TAZI", "Sara", "Avenue des FAR, Rabat", "0667890123");

            AfficherClients();

            Console.WriteLine("\n--- 2. UPDATE: Modification d'un client ---");
            ModifierClient(1, "ALAMI", "Ahmed", "Nouvelle adresse Tétouan", "0611111111");

            AfficherClients();

            Console.WriteLine("\n--- 3. DELETE: Suppression d'une commande ---");
            SupprimerCommande(1);

            AfficherCommandes();

            Console.WriteLine("\n--- 4. INSERT: Ajout de nouvelles commandes ---");
            AjouterCommande(2, DateTime.Now, 1);
            AjouterCommande(3, DateTime.Now.AddDays(5), 2);

            AfficherCommandes();
        }

        static void AjouterClient(string nom, string prenom, string adresse, string? numTel)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            string insertQuery = "INSERT INTO Clients (NomClient, PrenomClient, AdresseClient, NumTelClient) " +
                                "VALUES (@nom, @prenom, @adresse, @numTel)";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@nom", nom);
                cmd.Parameters.AddWithValue("@prenom", prenom);
                cmd.Parameters.AddWithValue("@adresse", adresse);
                cmd.Parameters.AddWithValue("@numTel", (object?)numTel ?? DBNull.Value);

                int rowsAffected = cmd.ExecuteNonQuery();

                Console.WriteLine($"✓ {rowsAffected} client(s) ajouté(s): {nom} {prenom}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Erreur lors de l'insertion: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        static void ModifierClient(int numClient, string nom, string prenom, string adresse, string? numTel)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            string updateQuery = "UPDATE Clients SET " +
                                "NomClient = @nom, " +
                                "PrenomClient = @prenom, " +
                                "AdresseClient = @adresse, " +
                                "NumTelClient = @numTel " +
                                "WHERE NumClient = @numClient";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(updateQuery, conn);
                cmd.Parameters.AddWithValue("@numClient", numClient);
                cmd.Parameters.AddWithValue("@nom", nom);
                cmd.Parameters.AddWithValue("@prenom", prenom);
                cmd.Parameters.AddWithValue("@adresse", adresse);
                cmd.Parameters.AddWithValue("@numTel", (object?)numTel ?? DBNull.Value);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                    Console.WriteLine($"✓ Client {numClient} modifié avec succès");
                else
                    Console.WriteLine($"✗ Aucun client trouvé avec le numéro {numClient}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Erreur lors de la modification: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        static void SupprimerCommande(int numComd)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            string deleteQuery = "DELETE FROM Commandes WHERE NumComd = @numComd";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(deleteQuery, conn);
                cmd.Parameters.AddWithValue("@numComd", numComd);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                    Console.WriteLine($"✓ Commande {numComd} supprimée avec succès");
                else
                    Console.WriteLine($"✗ Aucune commande trouvée avec le numéro {numComd}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Erreur lors de la suppression: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        static void AjouterCommande(int numClient, DateTime dateComd, int etatComd)
        {
            SqlConnection conn = new SqlConnection(connectionString);

            string insertQuery = "INSERT INTO Commandes (NumClient, DateComd, EtatComd) " +
                                "VALUES (@numClient, @dateComd, @etatComd)";

            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(insertQuery, conn);
                cmd.Parameters.AddWithValue("@numClient", numClient);
                cmd.Parameters.AddWithValue("@dateComd", dateComd);
                cmd.Parameters.AddWithValue("@etatComd", etatComd);

                int rowsAffected = cmd.ExecuteNonQuery();

                Console.WriteLine($"✓ {rowsAffected} commande(s) ajoutée(s) pour le client {numClient}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Erreur lors de l'insertion: {ex.Message}");
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
