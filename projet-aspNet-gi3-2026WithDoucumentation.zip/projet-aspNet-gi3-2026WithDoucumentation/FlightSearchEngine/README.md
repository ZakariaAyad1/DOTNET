# Moteur de Recherche de Vols ✈️

Application web ASP.NET Core MVC pour la recherche de vols utilisant l'API Amadeus.

## Fonctionnalités

### ✅ Implémentées

1. **Recherche de vols**
   - Vols aller simple ou aller-retour
   - Sélection de la ville de départ et d'arrivée
   - Dates de départ et de retour
   - Nombre de passagers (1-9)
   - Choix de la classe (Économique, Premium, Business, Première)

2. **Autocomplétion des villes**
   - Recherche dynamique des villes et aéroports
   - Affichage du nom de la ville, code IATA et pays
   - Utilisation de jQuery UI Autocomplete

3. **Affichage des résultats**
   - Présentation claire et moderne des vols
   - Informations détaillées sur chaque vol (heures, escales, durée)
   - Prix par passager avec devise
   - Indicateur de places disponibles
   - Badge pour vol direct ou avec escale

4. **Tri des résultats**
   - Par prix (croissant/décroissant)
   - Par durée de vol (croissant/décroissant)

5. **Filtres avancés**
   - Vol direct uniquement (sans escale)
   - Filtrage par heure de départ
   - Filtrage par heure d'arrivée

6. **Modification de la recherche**
   - Bouton "Modifier la recherche" qui conserve tous les paramètres
   - Retour au formulaire avec les données pré-remplies

## Configuration

### 1. Créer un compte Amadeus Developer

1. Allez sur [Amadeus for Developers](https://developers.amadeus.com/)
2. Créez un compte gratuit
3. Créez une nouvelle application dans votre dashboard
4. Récupérez votre **Client ID** et **Client Secret**

### 2. Configuration de l'application

Ouvrez le fichier `appsettings.json` et remplacez les valeurs suivantes :

```json
{
  "Amadeus": {
    "ClientId": "VOTRE_CLIENT_ID_ICI",
    "ClientSecret": "VOTRE_CLIENT_SECRET_ICI"
  }
}
```

⚠️ **Important** : Ne commitez jamais vos vraies credentials dans Git !

### 3. Installation et exécution

```powershell
# Naviguez vers le dossier du projet
cd FlightSearchEngine

# Restaurez les packages NuGet
dotnet restore

# Compilez le projet
dotnet build

# Lancez l'application
dotnet run
```

L'application sera accessible sur : https://localhost:5001 ou http://localhost:5000

## Structure du projet

```
FlightSearchEngine/
├── Controllers/
│   └── FlightController.cs        # Contrôleur principal pour la recherche de vols
├── Models/
│   ├── FlightSearchRequest.cs     # Modèle de requête de recherche
│   ├── FlightOffer.cs             # Modèles pour les offres de vol
│   └── City.cs                    # Modèle pour les villes
├── Services/
│   ├── IFlightSearchService.cs    # Interface du service
│   └── AmadeusFlightService.cs    # Implémentation avec l'API Amadeus
├── Views/
│   ├── Flight/
│   │   ├── Index.cshtml           # Page de recherche
│   │   └── Results.cshtml         # Page des résultats
│   └── Shared/
│       └── _Layout.cshtml         # Layout principal
└── appsettings.json               # Configuration
```

## Technologies utilisées

- **ASP.NET Core 10.0** - Framework web
- **C#** - Langage de programmation
- **Bootstrap 5** - Framework CSS
- **jQuery & jQuery UI** - Autocomplétion et interactions
- **Font Awesome** - Icônes
- **Amadeus API** - API de recherche de vols
- **Newtonsoft.Json** - Manipulation JSON

## API Amadeus

L'application utilise les endpoints suivants de l'API Amadeus :

1. **OAuth2 Token** : `/v1/security/oauth2/token`
   - Authentification et obtention du token d'accès

2. **Location Search** : `/v1/reference-data/locations`
   - Recherche de villes et d'aéroports pour l'autocomplétion

3. **Flight Offers Search** : `/v2/shopping/flight-offers`
   - Recherche de vols disponibles

## Limites de l'API (version Test)

- 1000 requêtes par mois (gratuit)
- Données de test uniquement
- Réservations non fonctionnelles

## Fonctionnalités futures possibles

- [ ] Réservation de vols
- [ ] Gestion des utilisateurs et connexion
- [ ] Historique des recherches
- [ ] Filtres supplémentaires (compagnies aériennes, nombre d'escales max)
- [ ] Export des résultats (PDF, Email)
- [ ] Mode multi-ville
- [ ] Comparaison de vols côte à côte
- [ ] Alertes de prix
- [ ] Intégration avec d'autres APIs (Sabre, Travelport)

## Dépannage

### Erreur 401 Unauthorized
- Vérifiez que vos credentials Amadeus sont corrects
- Assurez-vous que votre application Amadeus est active

### Aucun résultat trouvé
- Vérifiez que les codes IATA sont valides (3 lettres)
- Essayez avec des dates futures (minimum 7 jours)
- Les données de test peuvent être limitées pour certaines routes

### Autocomplétion ne fonctionne pas
- Vérifiez que jQuery et jQuery UI sont bien chargés
- Ouvrez la console du navigateur pour voir les erreurs JavaScript

## Support

Pour toute question ou problème :
- Consultez la [documentation Amadeus](https://developers.amadeus.com/self-service)
- Vérifiez les logs de l'application dans la console

## Auteur

Projet développé pour le cours de Technologie d'Entreprise - S9

## Licence

Ce projet est à but éducatif.
