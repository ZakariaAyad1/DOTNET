using FlightSearchEngine.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Text;

namespace FlightSearchEngine.Services
{
    public class AmadeusFlightService : IFlightSearchService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly string _baseUrl = "https://test.api.amadeus.com";
        private string? _accessToken;
        private DateTime _tokenExpiration;

        public AmadeusFlightService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
        }

        public async Task<string> GetAccessTokenAsync()
        {
            if (!string.IsNullOrEmpty(_accessToken) && DateTime.UtcNow < _tokenExpiration)
            {
                return _accessToken;
            }

            var clientId = _configuration["Amadeus:ClientId"];
            var clientSecret = _configuration["Amadeus:ClientSecret"];

            var request = new HttpRequestMessage(HttpMethod.Post, $"{_baseUrl}/v1/security/oauth2/token");
            var content = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("client_id", clientId ?? ""),
                new KeyValuePair<string, string>("client_secret", clientSecret ?? "")
            });

            request.Content = content;

            var response = await _httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var responseContent = await response.Content.ReadAsStringAsync();
            var tokenResponse = JsonConvert.DeserializeObject<JObject>(responseContent);

            _accessToken = tokenResponse?["access_token"]?.ToString();
            var expiresIn = tokenResponse?["expires_in"]?.Value<int>() ?? 1800;
            _tokenExpiration = DateTime.UtcNow.AddSeconds(expiresIn - 60);

            return _accessToken ?? string.Empty;
        }

        public async Task<List<City>> SearchCitiesAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query) || query.Length < 2)
                return new List<City>();

            try
            {
                var token = await GetAccessTokenAsync();
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var response = await _httpClient.GetAsync(
                    $"{_baseUrl}/v1/reference-data/locations?subType=CITY,AIRPORT&keyword={Uri.EscapeDataString(query)}&page[limit]=10");

                if (!response.IsSuccessStatusCode)
                    return new List<City>();

                var content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<JObject>(content);
                var data = result?["data"] as JArray;

                if (data == null)
                    return new List<City>();

                var cities = new List<City>();
                foreach (var item in data)
                {
                    cities.Add(new City
                    {
                        Name = item["name"]?.ToString() ?? "",
                        IataCode = item["iataCode"]?.ToString() ?? "",
                        Country = item["address"]?["countryName"]?.ToString() ?? ""
                    });
                }

                return cities;
            }
            catch
            {
                return new List<City>();
            }
        }

        public async Task<List<FlightOffer>> SearchFlightsAsync(FlightSearchRequest request)
        {
            try
            {
                var token = await GetAccessTokenAsync();
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

                var queryParams = new List<string>
                {
                    $"originLocationCode={request.DepartureCityCode}",
                    $"destinationLocationCode={request.ArrivalCityCode}",
                    $"departureDate={request.DepartureDate:yyyy-MM-dd}",
                    $"adults={request.NumberOfPassengers}",
                    $"travelClass={request.TravelClass}",
                    "nonStop=false",
                    "max=50"
                };

                if (request.IsRoundTrip && request.ReturnDate.HasValue)
                {
                    queryParams.Add($"returnDate={request.ReturnDate.Value:yyyy-MM-dd}");
                }

                var url = $"{_baseUrl}/v2/shopping/flight-offers?{string.Join("&", queryParams)}";
                var response = await _httpClient.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"API Error: {error}");
                    return new List<FlightOffer>();
                }

                var content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<JObject>(content);
                var data = result?["data"] as JArray;

                if (data == null)
                    return new List<FlightOffer>();

                var offers = new List<FlightOffer>();
                foreach (var item in data)
                {
                    var offer = ParseFlightOffer(item);
                    if (offer != null)
                        offers.Add(offer);
                }

                return offers;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                return new List<FlightOffer>();
            }
        }

        private FlightOffer? ParseFlightOffer(JToken data)
        {
            try
            {
                var offer = new FlightOffer
                {
                    Id = data["id"]?.ToString() ?? Guid.NewGuid().ToString(),
                    Price = data["price"]?["total"]?.Value<decimal>() ?? 0,
                    Currency = data["price"]?["currency"]?.ToString() ?? "EUR",
                    NumberOfBookableSeats = data["numberOfBookableSeats"]?.Value<int>() ?? 0,
                    ValidatingAirlineCodes = data["validatingAirlineCodes"]?[0]?.ToString() ?? ""
                };

                var itineraries = data["itineraries"] as JArray;
                if (itineraries != null)
                {
                    foreach (var itinerary in itineraries)
                    {
                        var segments = itinerary["segments"] as JArray;
                        if (segments == null) continue;

                        var itineraryObj = new Itinerary
                        {
                            Duration = itinerary["duration"]?.ToString() ?? ""
                        };

                        foreach (var segment in segments)
                        {
                            var segmentObj = new Segment
                            {
                                CarrierCode = segment["carrierCode"]?.ToString() ?? "",
                                Number = segment["number"]?.ToString() ?? "",
                                Duration = segment["duration"]?.ToString() ?? "",
                                NumberOfStops = segment["numberOfStops"]?.Value<int>() ?? 0,
                                Departure = new Departure
                                {
                                    IataCode = segment["departure"]?["iataCode"]?.ToString() ?? "",
                                    At = segment["departure"]?["at"]?.Value<DateTime>() ?? DateTime.MinValue,
                                    Terminal = segment["departure"]?["terminal"]?.ToString() ?? ""
                                },
                                Arrival = new Arrival
                                {
                                    IataCode = segment["arrival"]?["iataCode"]?.ToString() ?? "",
                                    At = segment["arrival"]?["at"]?.Value<DateTime>() ?? DateTime.MinValue,
                                    Terminal = segment["arrival"]?["terminal"]?.ToString() ?? ""
                                },
                                Aircraft = new Aircraft
                                {
                                    Code = segment["aircraft"]?["code"]?.ToString() ?? ""
                                }
                            };

                            itineraryObj.Segments.Add(segmentObj);
                        }

                        offer.Itineraries.Add(itineraryObj);
                    }
                }

                return offer;
            }
            catch
            {
                return null;
            }
        }
    }
}
