using FlightSearchEngine.Models;

namespace FlightSearchEngine.Services
{
    public interface IFlightSearchService
    {
        Task<string> GetAccessTokenAsync();
        Task<List<City>> SearchCitiesAsync(string query);
        Task<List<FlightOffer>> SearchFlightsAsync(FlightSearchRequest request);
    }
}
