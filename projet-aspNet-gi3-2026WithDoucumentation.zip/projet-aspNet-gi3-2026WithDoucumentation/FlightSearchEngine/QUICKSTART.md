# 🚀 Quick Start Guide

## Démarrage Rapide en 5 Minutes

### Étape 1 : Obtenir les Clés API (2 minutes)

1. Allez sur https://developers.amadeus.com/
2. Cliquez "Register" → Créez un compte
3. Cliquez "Create new app" → Nommez votre app
4. **Copiez** votre API Key (Client ID) et API Secret (Client Secret)

### Étape 2 : Configuration (1 minute)

Ouvrez `appsettings.json` et remplacez :

```json
"Amadeus": {
  "ClientId": "COLLEZ_VOTRE_API_KEY_ICI",
  "ClientSecret": "COLLEZ_VOTRE_API_SECRET_ICI"
}
```

### Étape 3 : Lancer (30 secondes)

Ouvrez le terminal dans le dossier FlightSearchEngine :

```powershell
dotnet run
```

### Étape 4 : Tester (1 minute)

1. Ouvrez votre navigateur : `https://localhost:5001`
2. Recherche exemple :
   - Départ : Paris
   - Arrivée : New York  
   - Départ : dans 10 jours
   - Retour : dans 17 jours
3. Cliquez "Rechercher des vols"

---

## ⚡ Commandes Essentielles

```powershell
# Lancer l'application
dotnet run

# Compiler
dotnet build

# Nettoyer
dotnet clean

# Restaurer les packages
dotnet restore
```

---

## 🎯 Première Recherche Recommandée

**Pour des résultats garantis, essayez :**
- Paris (CDG) → New York (JFK)
- Date : 7-30 jours dans le futur
- 1-2 passagers
- Classe Économique

---

## ❓ Problème ?

### "Erreur 401 Unauthorized"
→ Vérifiez vos credentials dans appsettings.json

### "Aucun résultat trouvé"
→ Essayez Paris-New York avec des dates futures

### L'autocomplétion ne marche pas
→ Tapez au moins 2 caractères et attendez 1 seconde

---

## 📚 Documentation Complète

- **SETUP_GUIDE.md** - Configuration détaillée
- **TEST_GUIDE.md** - Guide de test
- **PROJECT_SUMMARY.md** - Vue d'ensemble complète
- **README.md** - Documentation principale

---

## ✅ Checklist Première Utilisation

- [ ] Compte Amadeus créé
- [ ] Credentials copiés dans appsettings.json
- [ ] Application lancée (`dotnet run`)
- [ ] Navigateur ouvert (https://localhost:5001)
- [ ] Première recherche réussie

---

**C'est tout ! Vous êtes prêt ! 🎉**

En cas de problème, consultez SETUP_GUIDE.md
