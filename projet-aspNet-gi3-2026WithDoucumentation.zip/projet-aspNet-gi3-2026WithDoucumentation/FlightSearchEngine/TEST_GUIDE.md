# Guide de Test - FlightSearchEngine

## Tests Fonctionnels

### Test 1 : Recherche de vol simple

#### Objectif
Tester la recherche basique de vols

#### Étapes
1. Lancez l'application (`dotnet run`)
2. Ouvrez `https://localhost:5001`
3. Remplissez le formulaire :
   - Type : Aller-Retour (coché)
   - Ville de départ : Paris
   - Ville d'arrivée : New York
   - Date de départ : (aujourd'hui + 10 jours)
   - Date de retour : (aujourd'hui + 17 jours)
   - Passagers : 2
   - Classe : Économique
4. Cliquez sur "Rechercher des vols"

#### Résultat attendu
- Page de résultats affichée
- Liste de vols disponibles
- Prix affichés
- Détails des vols (heures, escales)

---

### Test 2 : Autocomplétion des villes

#### Objectif
Vérifier que l'autocomplétion fonctionne correctement

#### Étapes
1. Dans le champ "Ville de départ", tapez "Par"
2. Attendez 1-2 secondes
3. Sélectionnez "Paris (CDG) - France" dans la liste

#### Résultat attendu
- Suggestions apparaissent après avoir tapé 2 caractères
- Les suggestions contiennent : nom de ville, code IATA, pays
- Sélection remplit automatiquement le champ

#### Villes à tester
- "Par" → Paris, Parme, etc.
- "New" → New York, New Delhi, etc.
- "Lon" → Londres, etc.
- "Mad" → Madrid, etc.
- "Cas" → Casablanca, etc.

---

### Test 3 : Vol aller simple

#### Objectif
Tester la recherche de vol aller simple (sans retour)

#### Étapes
1. Sélectionnez "Aller Simple"
2. Remplissez :
   - Départ : Londres (LHR)
   - Arrivée : Paris (CDG)
   - Date : (aujourd'hui + 7 jours)
   - Passagers : 1
   - Classe : Business
3. Cliquez sur "Rechercher"

#### Résultat attendu
- Résultats affichés
- Uniquement des vols aller (pas de retour)
- Prix pour la classe Business

---

### Test 4 : Tri des résultats

#### Objectif
Vérifier que le tri fonctionne

#### Étapes
1. Effectuez une recherche (voir Test 1)
2. Modifiez la recherche
3. Dans "Filtres avancés", sélectionnez "Trier par"
4. Testez chaque option :
   - Prix croissant
   - Prix décroissant
   - Durée croissante
   - Durée décroissante

#### Résultat attendu
- Les résultats sont triés selon le critère choisi
- Le vol le moins cher apparaît en premier (prix croissant)
- Le vol le plus court apparaît en premier (durée croissante)

---

### Test 5 : Filtre vol direct

#### Objectif
Filtrer uniquement les vols directs

#### Étapes
1. Effectuez une recherche
2. Modifiez la recherche
3. Dans "Filtres avancés", cochez "Vol direct uniquement"
4. Lancez la recherche

#### Résultat attendu
- Seuls les vols directs sont affichés
- Badge "Vol direct" visible sur chaque résultat
- Aucun vol avec escale

---

### Test 6 : Filtre par heure de départ

#### Objectif
Filtrer les vols par heure de départ

#### Étapes
1. Effectuez une recherche
2. Modifiez la recherche
3. Dans "Filtres avancés" :
   - Heure de départ de : 08:00
   - Heure de départ à : 12:00
4. Lancez la recherche

#### Résultat attendu
- Seuls les vols partant entre 8h et 12h sont affichés
- Vérifier les heures de départ sur les résultats

---

### Test 7 : Modification de recherche

#### Objectif
Vérifier que la fonctionnalité "Modifier" conserve les données

#### Étapes
1. Effectuez une recherche complète avec tous les champs remplis
2. Sur la page de résultats, cliquez sur "Modifier la recherche"
3. Vérifiez que tous les champs sont pré-remplis

#### Résultat attendu
- Retour au formulaire de recherche
- Tous les champs contiennent les valeurs précédentes
- Aucune donnée perdue

---

### Test 8 : Différentes classes

#### Objectif
Tester les différentes classes de voyage

#### Étapes
Pour chaque classe, effectuez une recherche :
1. Économique
2. Économique Premium
3. Business
4. Première Classe

#### Résultat attendu
- Les prix varient selon la classe
- Les résultats correspondent à la classe demandée

---

### Test 9 : Différents nombres de passagers

#### Objectif
Vérifier le calcul pour plusieurs passagers

#### Étapes
1. Recherchez avec 1 passager - Notez le prix
2. Recherchez avec 3 passagers - Comparez le prix

#### Résultat attendu
- Le prix augmente proportionnellement au nombre de passagers
- "pour X passager(s)" affiché correctement

---

### Test 10 : Validation des dates

#### Objectif
Vérifier que les validations de dates fonctionnent

#### Étapes
1. Essayez de sélectionner une date passée
2. Pour un aller-retour, essayez de mettre la date de retour avant la date d'aller

#### Résultat attendu
- Impossible de sélectionner une date passée
- La date de retour minimum = date de départ

---

## Tests d'Interface

### Responsive Design

#### Étapes
1. Ouvrez l'application dans le navigateur
2. Appuyez sur F12 pour ouvrir les DevTools
3. Activez le mode responsive
4. Testez différentes tailles :
   - Mobile (375px)
   - Tablette (768px)
   - Desktop (1920px)

#### Résultat attendu
- Le layout s'adapte correctement
- Tous les éléments sont visibles et utilisables
- Pas de débordement horizontal

---

### Navigation

#### Étapes
1. Cliquez sur le logo "FlightSearch" dans la navbar
2. Cliquez sur "Rechercher" dans le menu

#### Résultat attendu
- Retour à la page de recherche
- Navigation fluide

---

## Tests d'Erreurs

### Test API indisponible

#### Étapes
1. Dans `appsettings.json`, mettez des credentials incorrects
2. Essayez une recherche

#### Résultat attendu
- Message d'erreur approprié
- Pas de crash de l'application

---

### Test champs vides

#### Étapes
1. Essayez de soumettre le formulaire sans remplir les champs

#### Résultat attendu
- Messages de validation affichés
- Formulaire non soumis

---

## Checklist complète

- [ ] Recherche aller-retour fonctionne
- [ ] Recherche aller simple fonctionne
- [ ] Autocomplétion des villes fonctionne
- [ ] Tri par prix (croissant) fonctionne
- [ ] Tri par prix (décroissant) fonctionne
- [ ] Tri par durée (croissant) fonctionne
- [ ] Tri par durée (décroissant) fonctionne
- [ ] Filtre vol direct fonctionne
- [ ] Filtre heure de départ fonctionne
- [ ] Filtre heure d'arrivée fonctionne
- [ ] Modification de recherche conserve les données
- [ ] Validation des formulaires fonctionne
- [ ] Design responsive (mobile, tablette, desktop)
- [ ] Navigation fonctionnelle
- [ ] Gestion d'erreurs API
- [ ] Affichage correct des prix
- [ ] Affichage correct des escales
- [ ] Badges (vol direct, escales) corrects
- [ ] Indicateur places disponibles visible

---

## Résultats attendus globaux

### Performance
- Temps de réponse API : < 3 secondes
- Chargement page : < 2 secondes
- Autocomplétion : < 1 seconde

### Qualité
- Pas d'erreurs JavaScript dans la console
- Pas d'erreurs 404 (ressources manquantes)
- Design cohérent et professionnel

### Fonctionnalité
- Toutes les fonctionnalités requises implémentées
- Filtres et tris opérationnels
- Données conservées lors de la modification

---

## Rapport de bug (si problème)

Si vous rencontrez un problème, notez :

1. **Étape** : Quelle action avez-vous effectuée ?
2. **Attendu** : Quel était le résultat attendu ?
3. **Obtenu** : Qu'est-ce qui s'est réellement passé ?
4. **Console** : Y a-t-il des erreurs dans la console (F12) ?
5. **Navigateur** : Quel navigateur utilisez-vous ?

---

**Bonne chance pour les tests ! 🧪**
