namespace FlightSearchEngine.Models
{
    public class FlightOffer
    {
        public string Id { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string Currency { get; set; } = "EUR";
        public int NumberOfBookableSeats { get; set; }
        public List<Itinerary> Itineraries { get; set; } = new();
        public string ValidatingAirlineCodes { get; set; } = string.Empty;
    }

    public class Itinerary
    {
        public string Duration { get; set; } = string.Empty;
        public List<Segment> Segments { get; set; } = new();

        public int GetTotalMinutes()
        {
            if (string.IsNullOrEmpty(Duration)) return 0;

            // Parse ISO 8601 duration format (PT1H30M)
            var duration = Duration.Replace("PT", "");
            int hours = 0, minutes = 0;

            if (duration.Contains("H"))
            {
                var parts = duration.Split('H');
                int.TryParse(parts[0], out hours);
                if (parts.Length > 1 && parts[1].Contains("M"))
                {
                    int.TryParse(parts[1].Replace("M", ""), out minutes);
                }
            }
            else if (duration.Contains("M"))
            {
                int.TryParse(duration.Replace("M", ""), out minutes);
            }

            return hours * 60 + minutes;
        }

        public bool IsDirect()
        {
            return Segments.Count == 1;
        }
    }

    public class Segment
    {
        public Departure Departure { get; set; } = new();
        public Arrival Arrival { get; set; } = new();
        public string CarrierCode { get; set; } = string.Empty;
        public string Number { get; set; } = string.Empty;
        public Aircraft Aircraft { get; set; } = new();
        public string Duration { get; set; } = string.Empty;
        public int NumberOfStops { get; set; }
    }

    public class Departure
    {
        public string IataCode { get; set; } = string.Empty;
        public DateTime At { get; set; }
        public string Terminal { get; set; } = string.Empty;
    }

    public class Arrival
    {
        public string IataCode { get; set; } = string.Empty;
        public DateTime At { get; set; }
        public string Terminal { get; set; } = string.Empty;
    }

    public class Aircraft
    {
        public string Code { get; set; } = string.Empty;
    }
}
