using System.ComponentModel.DataAnnotations;

namespace FlightSearchEngine.Models
{
    public class FlightSearchRequest
    {
        [Required(ErrorMessage = "La ville de départ est obligatoire")]
        [Display(Name = "Ville de départ")]
        public string DepartureCity { get; set; } = string.Empty;

        [Required(ErrorMessage = "Le code IATA de départ est obligatoire")]
        public string DepartureCityCode { get; set; } = string.Empty;

        [Required(ErrorMessage = "La ville d'arrivée est obligatoire")]
        [Display(Name = "Ville d'arrivée")]
        public string ArrivalCity { get; set; } = string.Empty;

        [Required(ErrorMessage = "Le code IATA d'arrivée est obligatoire")]
        public string ArrivalCityCode { get; set; } = string.Empty;

        [Required(ErrorMessage = "La date de départ est obligatoire")]
        [Display(Name = "Date de départ")]
        [DataType(DataType.Date)]
        public DateTime DepartureDate { get; set; }

        [Display(Name = "Date de retour")]
        [DataType(DataType.Date)]
        public DateTime? ReturnDate { get; set; }

        [Required(ErrorMessage = "Le nombre de passagers est obligatoire")]
        [Display(Name = "Nombre de passagers")]
        [Range(1, 9, ErrorMessage = "Le nombre de passagers doit être entre 1 et 9")]
        public int NumberOfPassengers { get; set; } = 1;

        [Required(ErrorMessage = "La classe est obligatoire")]
        [Display(Name = "Classe")]
        public string TravelClass { get; set; } = "ECONOMY";

        [Display(Name = "Vol aller-retour")]
        public bool IsRoundTrip { get; set; } = true;

        // For sorting and filtering
        public string? SortBy { get; set; }
        public bool DirectFlightOnly { get; set; } = false;
        public TimeSpan? DepartureTimeFrom { get; set; }
        public TimeSpan? DepartureTimeTo { get; set; }
        public TimeSpan? ArrivalTimeFrom { get; set; }
        public TimeSpan? ArrivalTimeTo { get; set; }
    }
}
