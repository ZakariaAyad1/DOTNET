# Guide de Configuration - FlightSearchEngine

## Étape 1 : Obtenir les clés API Amadeus

### 1.1 Créer un compte Amadeus Developer

1. Visitez [https://developers.amadeus.com/](https://developers.amadeus.com/)
2. Cliquez sur "Register" en haut à droite
3. Remplissez le formulaire d'inscription :
   - Email
   - Mot de passe
   - Prénom et nom
   - Pays
4. Vérifiez votre email et activez votre compte

### 1.2 Créer une application

1. Connectez-vous à votre compte Amadeus
2. Allez dans "My Self-Service Workspace"
3. Cliquez sur "Create new app"
4. Remplissez les informations :
   - **App Name** : FlightSearchEngine (ou un nom de votre choix)
   - **App Type** : Personal
   - **Description** : Application de recherche de vols pour projet académique
5. Cliquez sur "Create"

### 1.3 Récupérer les credentials

1. Dans votre dashboard, cliquez sur votre application
2. Vous verrez deux informations importantes :
   - **API Key** (c'est votre Client ID)
   - **API Secret** (c'est votre Client Secret)
3. **Important** : Notez ces informations dans un endroit sûr !

## Étape 2 : Configuration de l'application

### 2.1 Configurer appsettings.json

1. Ouvrez le fichier `appsettings.json` dans le projet
2. Remplacez les valeurs par défaut par vos vraies credentials :

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*",
  "Amadeus": {
    "ClientId": "mettez_votre_API_KEY_ici",
    "ClientSecret": "mettez_votre_API_SECRET_ici"
  }
}
```

### 2.2 Alternative : User Secrets (Recommandé pour le développement)

Pour plus de sécurité, vous pouvez utiliser User Secrets :

```powershell
# Dans le terminal, naviguez vers le dossier du projet
cd FlightSearchEngine

# Initialisez les User Secrets
dotnet user-secrets init

# Ajoutez vos credentials
dotnet user-secrets set "Amadeus:ClientId" "VOTRE_CLIENT_ID"
dotnet user-secrets set "Amadeus:ClientSecret" "VOTRE_CLIENT_SECRET"
```

Avec cette méthode, vos credentials ne seront jamais dans le code source !

## Étape 3 : Installer les dépendances

```powershell
# Naviguez vers le dossier du projet
cd FlightSearchEngine

# Restaurez les packages NuGet
dotnet restore
```

## Étape 4 : Compiler et exécuter

```powershell
# Compilez le projet
dotnet build

# Lancez l'application
dotnet run
```

Vous devriez voir une sortie similaire à :

```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: https://localhost:5001
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5000
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to shut down.
```

## Étape 5 : Tester l'application

1. Ouvrez votre navigateur
2. Allez sur `https://localhost:5001` ou `http://localhost:5000`
3. Vous devriez voir le formulaire de recherche de vols

### Test de l'autocomplétion

1. Dans le champ "Ville de départ", tapez "Par"
2. Vous devriez voir apparaître des suggestions comme "Paris"
3. Sélectionnez une ville

### Test de recherche

Essayez une recherche avec ces paramètres :
- **Départ** : Paris (CDG)
- **Arrivée** : New York (JFK)
- **Date de départ** : Une date dans 7-30 jours
- **Date de retour** : 7 jours après la date de départ
- **Passagers** : 1
- **Classe** : Économique

Cliquez sur "Rechercher des vols"

## Vérification des problèmes courants

### Problème 1 : Erreur 401 Unauthorized

**Cause** : Credentials incorrects ou expirés

**Solution** :
1. Vérifiez que vous avez copié correctement le Client ID et Client Secret
2. Assurez-vous qu'il n'y a pas d'espaces avant/après les credentials
3. Vérifiez que votre application Amadeus est bien active dans le dashboard

### Problème 2 : Aucun résultat de recherche

**Cause** : Données de test limitées

**Solution** :
1. Essayez avec des routes populaires (Paris-New York, Londres-Paris, etc.)
2. Utilisez des dates futures (minimum 7 jours)
3. L'API de test a des données limitées

### Problème 3 : L'autocomplétion ne fonctionne pas

**Cause** : jQuery UI non chargé ou erreur JavaScript

**Solution** :
1. Ouvrez la console du navigateur (F12)
2. Vérifiez qu'il n'y a pas d'erreurs JavaScript
3. Assurez-vous que jQuery et jQuery UI sont bien chargés

### Problème 4 : Erreur de compilation

**Cause** : Packages manquants ou version .NET incorrecte

**Solution** :
```powershell
# Vérifiez votre version de .NET
dotnet --version

# Devrait être 8.0 ou supérieur

# Nettoyez et restaurez
dotnet clean
dotnet restore
dotnet build
```

## Limites de l'API Test

- **1000 requêtes par mois** (gratuit)
- **Données de test uniquement** (pas de vraies réservations)
- **Routes limitées** (principalement Europe et Amérique du Nord)
- **Pas de réservation réelle** (seulement recherche)

## Pour passer en Production

Si vous voulez utiliser l'API en production :

1. Contactez Amadeus pour un compte production
2. Vous aurez des credentials différents
3. Changez l'URL de base dans `AmadeusFlightService.cs` :
   ```csharp
   // Test
   private readonly string _baseUrl = "https://test.api.amadeus.com";
   
   // Production
   private readonly string _baseUrl = "https://api.amadeus.com";
   ```

## Support

- **Documentation Amadeus** : https://developers.amadeus.com/self-service
- **Forum communautaire** : https://developers.amadeus.com/support
- **Status API** : https://developers.amadeus.com/status

## Ressources supplémentaires

- [Amadeus API Documentation](https://developers.amadeus.com/self-service/category/flights)
- [ASP.NET Core Documentation](https://docs.microsoft.com/en-us/aspnet/core/)
- [Bootstrap Documentation](https://getbootstrap.com/docs/5.3/)

---

**Bon développement ! 🚀**
